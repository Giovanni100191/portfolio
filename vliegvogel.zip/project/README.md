# Flappy Bird Festival Edition 🐦

Een moderne versie van Flappy Bird, perfect voor je SectorFestival!

## Features ✨

- Mooie graphics met animaties
- Score systeem
- Responsive design
- Eenvoudige besturing
- Werkt direct in de browser

## Hoe te spelen 🎮

1. Open `index.html` in je webbrowser
2. Besturing:
   - Klik met de muis of druk op SPATIE om te springen
   - Vermijd de groene buizen
   - Probeer zo hoog mogelijk te scoren!

## Technische Details 💻

- Gebouwd met HTML5 Canvas
- Pure JavaScript (geen frameworks nodig)
- Moderne CSS styling
- Responsive design

## Perfect voor je Festival! 🎉

- Geen installatie nodig
- Werkt op alle apparaten
- Visueel aantrekkelijk
- Makkelijk te demonstreren
- Interactief voor bezoekers 