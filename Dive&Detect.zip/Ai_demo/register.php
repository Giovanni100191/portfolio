<?php
// Include de databaseconfiguratie
include 'config.php';

if (isset($_POST['register'])) {
    // Haal de form-gegevens op
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $country = $_POST['country'];

    // Verwerken van de profielfoto
    $profile_picture = 'media/default-profile.jpg';
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        $file_tmp = $_FILES['profile_picture']['tmp_name'];
        $file_name = $_FILES['profile_picture']['name'];
        $file_path = 'media/' . $file_name;

        move_uploaded_file($file_tmp, $file_path);
        $profile_picture = $file_path;
    }

    // Maak verbinding met de database
    $database = new Database();
    $db = $database->getConnection();

    // Voer de SQL-query uit om een nieuw account aan te maken
    $sql = "INSERT INTO dive_detect_users (username, email, password, first_name, last_name, country, profile_picture) 
            VALUES (:username, :email, :password, :first_name, :last_name, :country, :profile_picture)";

    $stmt = $db->prepare($sql);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password', $password);
    $stmt->bindParam(':first_name', $first_name);
    $stmt->bindParam(':last_name', $last_name);
    $stmt->bindParam(':country', $country);
    $stmt->bindParam(':profile_picture', $profile_picture);

    // Uitvoeren van de query
    if ($stmt->execute()) {
        echo "Account succesvol aangemaakt!";
    } else {
        echo "Fout bij het aanmaken van account!";
    }
}
?>
