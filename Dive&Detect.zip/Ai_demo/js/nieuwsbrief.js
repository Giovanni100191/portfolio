document.addEventListener("DOMContentLoaded", function () {
    const refreshButton = document.querySelector("#loadMore");

    refreshButton.addEventListener("click", function () {
        // Refresh de pagina na een korte vertraging
        refreshButton.classList.add("rotate");
        setTimeout(() => {
            location.reload();
        }, 500);
    });
});
