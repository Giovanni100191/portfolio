document.addEventListener("DOMContentLoaded", function() {
    let bubbleContainer = document.querySelector(".bubbles");

    function createBubble() {
        let bubble = document.createElement("div");
        bubble.classList.add("bubble");
        bubble.style.left = Math.random() * 100 + "vw";
        bubble.style.animationDuration = Math.random() * 3 + 2 + "s";
        bubbleContainer.appendChild(bubble);
        setTimeout(() => bubble.remove(), 5000);
    }

    setInterval(createBubble, 500);

    let randomTime = (Math.floor(Math.random() * 3) + 3) * 1000;
    setTimeout(() => {
        window.location.href = 'home.php';
    }, randomTime);
});
