<?php
session_start();

// Controleren of de gebruiker is ingelogd
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'config.php';

// Verkrijg de gebruikers-ID van de ingelogde gebruiker
$user_id = $_SESSION['user_id'];

// Haal de gebruikersgegevens op uit de database
$query = "SELECT * FROM dive_detect_users WHERE id = :user_id";
$stmt = $pdo->prepare($query);
$stmt->execute(['user_id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Controleer of de query gegevens heeft opgehaald
if (!$user) {
    echo 'Gebruiker niet gevonden!';
    exit();
}

// Include de view voor het profiel
include 'views/profiel_view.php';
?>
