<?php
session_start();
include 'config.php';

// Check of de gebruiker is ingelogd
if (!isset($_SESSION['user_id'])) {
    $isLoggedIn = false;
} else {
    $isLoggedIn = true;
    $userId = $_SESSION['user_id'];

    try {
        // Haal XP en level op uit de database
        $query = "SELECT xp, level FROM dive_detect_users WHERE id = :user_id";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        $xp = $result['xp'] ?? 0;
        $level = $result['level'] ?? 1;

        // Verkrijg de vissen die de speler heeft gevangen
        $caughtFish = [];
        $fishesQuery = "SELECT fish_naam FROM dive_detect_fishing WHERE user_id = :user_id";
        $stmt = $pdo->prepare($fishesQuery);
        $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        $caughtFish = $stmt->fetchAll(PDO::FETCH_COLUMN);

        // Verwerken van gevangen vissen
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fish_name'])) {
            $fishName = $_POST['fish_name'];

            // Controleer of de vis al bestaat
            $selectQuery = "SELECT id, fish_count FROM dive_detect_fishing WHERE user_id = :user_id AND fish_naam = :fish_name";
            $stmt = $pdo->prepare($selectQuery);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':fish_name', $fishName, PDO::PARAM_STR);
            $stmt->execute();
            $fish = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($fish) {
                // Verhoog het aantal gevangen vissen
                $newCount = $fish['fish_count'] + 1;
                $updateQuery = "UPDATE dive_detect_fishing SET fish_count = :fish_count WHERE id = :id";
                $stmt = $pdo->prepare($updateQuery);
                $stmt->bindParam(':fish_count', $newCount, PDO::PARAM_INT);
                $stmt->bindParam(':id', $fish['id'], PDO::PARAM_INT);
                $stmt->execute();
            } else {
                // Voeg nieuwe vis toe met count 1
                $insertQuery = "INSERT INTO dive_detect_fishing (user_id, fish_naam, fish_count) VALUES (:user_id, :fish_name, 1)";
                $stmt = $pdo->prepare($insertQuery);
                $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
                $stmt->bindParam(':fish_name', $fishName, PDO::PARAM_STR);
                $stmt->execute();
            }

            // Voeg 35 XP toe en update de database
            $xp += 35;
            $level = floor($xp / 100) + 1;

            $updateXPQuery = "UPDATE dive_detect_users SET xp = :xp, level = :level WHERE id = :user_id";
            $stmt = $pdo->prepare($updateXPQuery);
            $stmt->bindParam(':xp', $xp, PDO::PARAM_INT);
            $stmt->bindParam(':level', $level, PDO::PARAM_INT);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->execute();

            // Stuur de bijgewerkte XP en level terug naar de frontend
            echo json_encode(["xp" => $xp, "level" => $level]);
            exit;
        }

    } catch (PDOException $e) {
        die("Databasefout: " . $e->getMessage());
    }
}

include('views/duiken_view.php');
?>
