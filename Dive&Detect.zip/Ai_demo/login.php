<?php
// Config bestand inladen voor databaseverbinding
include 'config.php';

// Start de sessie
session_start();

$error = ''; // Foutmelding

// Controleren of het formulier is ingediend
if (isset($_POST['login'])) {
    // Verkrijg de formuliergegevens
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Validatie: controleer of de velden niet leeg zijn
    if (empty($username) || empty($password)) {
        $error = "Alle velden zijn verplicht.";
    } else {
        // Zoek de gebruiker op in de database
        $query = "SELECT * FROM dive_detect_users WHERE username = :username";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['username' => $username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Controleer of de gebruiker bestaat
        if ($user) {
            // Vergelijk het ingevoerde wachtwoord met het gehasht wachtwoord in de database
            if (password_verify($password, $user['password'])) {
                // Wachtwoord is correct, log de gebruiker in
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['first_name'] = $user['first_name'];

                // Redirect naar de gebruikerspagina of een dashboard
                header("Location: profiel.php"); // Vervang dashboard.php door de juiste pagina
                exit;
            } else {
                $error = "Ongeldig wachtwoord.";
            }
        } else {
            $error = "De opgegeven gebruikersnaam bestaat niet.";
        }
    }
}

// Toon de view
include 'views/login_view.php';
?>
