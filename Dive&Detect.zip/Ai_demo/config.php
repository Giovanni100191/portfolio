<?php
// Databasegegevens
$host = 'localhost'; // Of gebruik het IP-adres van de server
$dbname = 'dbberoeps_100884'; // De naam van je database
$username = 'db-100884'; // Vervang dit door je database gebruikersnaam
$password = 'Hockeyhbr2006!'; // Vervang dit door je database wachtwoord

try {
    // Maak de verbinding met de database
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Zet de PDO foutmodus op Exception voor foutopsporing
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Als de verbinding niet kan worden gemaakt, toon een foutmelding
    echo "Verbinding met de database is mislukt: " . $e->getMessage();
    exit;
}
?>
