<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dive & Detect</title>
    <link rel="stylesheet" href="css/index.css">
</head>
<body>

<div class="startup-screen">
    <div class="logo">Dive & Detect</div>
    <div class="bubbles"></div>
</div>

<script src="js/index.js"></script>
</body>
</html>
