<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dive+Detect</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="public/footer.css">
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
</head>
<body>
<a href="home.php" class="logo-link">
    <img src="media/logo.png" alt="Logo" class="logo-img">
</a>

<div class="container">
    <h1>Dive+Detect</h1>

    <div class="card">
        <img src="media/diver.png" alt="Duiker">
        <div class="card-body">
            <a href="duiken.php" class="btn btn-custom">Klik hier om de game te spelen</a>
        </div>
    </div>

    <div class="card">
        <img src="media/ai_home.jpg" alt="AI">
        <div class="card-body">
            <a href="ai.php" class="btn btn-custom">Gebruik onze AI om uw te helpen</a>
        </div>
    </div>

    <div class="card">
        <img src="media/news_home.jpg" alt="Vis van de maand">
        <div class="card-body">
            <a href="nieuwsbrief.php" class="btn btn-custom">Lees de nieuwsbrief voor de nieuwste ontdekkingen</a>
        </div>
    </div>
</div>
<br><br><br>

<?php include "shared/footer.php"; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
