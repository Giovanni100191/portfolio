<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dive+Detect - Duiken en Ontdekken</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/jquery.js"></script>
    <script src="js/turn.js"></script>
    <link rel="stylesheet" href="css/duiken.css">
    <link rel="stylesheet" href="css/bookAnimation.css">
    <link rel="stylesheet" href="public/footer.css">
</head>
<body>

<?php if (!$isLoggedIn): ?>
    <style>
        body {
            background-repeat: no-repeat;
            background-size: 100%;
            height: 100vh;
        }
        #homeButton {
            font-size: 0.8rem;
            color: #ffffff;
            text-decoration: none;
            background-color: rgba(0, 0, 0, 0.6);
            padding: 10px 20px;
            border-radius: 20px;
            border: 1px solid #ffffff;
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        #homeButton:hover {
            background-color: rgba(0, 0, 0, 0.8);
            color: #3ff3e5;
        }

        .alert {
            margin-bottom: 20px;
        }

        .container {
            height: 100vh;
        }
    </style>
    <div class="container d-flex flex-column justify-content-center align-items-center">
        <div class="position-absolute top-0 start-0 m-3">
            <a id="homeButton" href="home.php" class="text-white">Terug naar home</a>
        </div>

        <div class="row w-100 justify-content-center">
            <div class="col-12">
                <div class="alert alert-dark text-center" role="alert" style="border-radius: 25px;">
                    Je moet inloggen om verder te gaan!
                </div>
            </div>
        </div>

        <div class="row w-100 justify-content-center">
            <div class="col-auto">
                <a href="login.php" class="btn" style="background-color: #000000; color: #3ff3e5; border: 1px solid white;">Inloggen</a>
            </div>
        </div>
    </div>

    <?php include "shared/footer.php"; ?>

<?php else: ?>
    <!-- Startscherm -->
    <div id="startScreen" class="d-flex flex-column justify-content-center align-items-center vh-100" style="background: url('media/duiken_bg.jpg') center/cover no-repeat;">
        <button id="indexBtn">Vis Index</button>
        <h1 class="text-white mb-4">Welkom bij Dive+Detect</h1>
        <button id="startGameBtn" class="btn btn-primary btn-lg">Start Spel</button>
    </div>

    <!-- Spel Container, verborgen tot gebruiker op start drukt -->
    <div id="gameContainer" style="display: none;">
        <div id="hookLine"></div>
        <img id="hook" src="media/vishaak.png" alt="Haak">

        <div id="objectsContainer"></div>
        <div id="scoreBoard">
            <p>XP: <span id="xp"><?php echo $xp; ?></span></p>
            <p>Level: <span id="level"><?php echo $level; ?></span></p>
        </div>
    </div>

    <div style="z-index: 10;" id="fishBook" class="hidden">
        <div class="flipbook">
            <div class="hard">My fish index <small>~ <?php echo $_SESSION['username']; ?></small></div>
            <div class="hard"></div>
            <div>
                <small>Dit is de vissen index.</small>
                <small>Laten wij kijken wat je hebt gevangen!!️</small>
            </div>
            <?php
            $allFish = ["zalm", "forel", "haring", "sardine", "snoek", "tonijn", "baars"];
            foreach ($allFish as $fish):
                ?>
                <div>
                    <img src="media/<?php echo $fish; ?>.png" alt="<?php echo ucfirst($fish); ?>"
                         class="fish-entry <?php echo in_array($fish, $caughtFish) ? '' : 'not-caught'; ?>" />
                    <small><?php echo ucfirst($fish); ?></small>
                </div>
            <?php endforeach; ?>
            <div class="hard"></div>
        </div>
        <button id="closeBook">Sluiten</button>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const startBtn = document.getElementById("startGameBtn");
            const startScreen = document.getElementById("startScreen");
            const gameContainer = document.getElementById("gameContainer");

            startBtn.addEventListener("click", function () {
                startScreen.style.visibility = "hidden";
                startScreen.style.pointerEvents = "none";
                gameContainer.style.display = "block";
            });
        });

        let xp = <?php echo $xp; ?>;
        let level = <?php echo $level; ?>;

        function updateFishBook(fishName) {
            let fishImg = document.querySelector(`img[alt='${fishName}']`);
            if (fishImg) {
                fishImg.classList.remove("not-caught");
            }
        }

        document.addEventListener("DOMContentLoaded", function () {
            $(".fish").click(function () {
                let fishName = $(this).attr("alt");

                $.post("duiken.php", { fish_name: fishName }, function (data) {
                    let response = JSON.parse(data);
                    $("#xp").text(response.xp);
                    $("#level").text(response.level);
                    updateFishBook(fishName);
                });
            });
        });
    </script>

    <script src="js/duiken.js" defer></script>
    <script>
        $(".flipbook").turn();
    </script>
<?php endif; ?>

</body>
</html>
