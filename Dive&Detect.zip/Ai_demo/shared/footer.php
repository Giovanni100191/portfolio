
<!-- Navigatiebalk onderaan -->
<div class="footer-nav text-center">
    <a href="home.php"><i class="bi bi-house"></i></a>
    <a href="nieuwsbrief.php"><i class="bi bi-newspaper"></i></a>
    <a href="duiken.php"><i class="bi bi-joystick"></i></a>
    <a href="ai.php"><i class="bi bi-cpu"></i></a>
    <a href="profiel.php"><i class="bi bi-person"></i></a>
</div>
