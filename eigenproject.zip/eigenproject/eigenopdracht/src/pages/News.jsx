import React, { useState, useEffect } from 'react';
import '../styles/News.css';
import Header from '../components/Header';

const News = () => {
  const [news, setNews] = useState([]);
  const [upcomingReleases, setUpcomingReleases] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulated data - in a real app, this would come from an API
    const mockNews = [
      {
        id: 1,
        title: "GTA 6 Nieuwe Release Datum Bekendgemaakt",
        date: "13-6-2025",
        summary: "Rockstar Games heeft de officiële release datum bekendgemaakt voor GTA 6. Het spel komt uit op 13 juni 2025 en belooft de grootste open wereld tot nu toe met een verhaal dat zich afspeelt in Vice City.",
        image: "/images/gta6.jpg"
      },
      {
        id: 2,
        title: "Fortnite: Nieuwe Season 'Mythical Legends'",
        date: "13-6-2025",
        summary: "Epic Games kondigt de nieuwe Fortnite season aan met een thema gebaseerd op mythologische wezens. Nieuwe skins, wapens en een compleet vernieuwde map wachten op spelers.",
        image: "/images/fortnitenew.jpg"
      },
      {
        id: 3,
        title: "Phasmophobia 2.0 Update: Nieuwe Geesten en Locaties",
        date: "13-6-2025",
        summary: "De langverwachte 2.0 update voor Phasmophobia brengt nieuwe geesten, locaties en gameplay mechanics. De graphics zijn volledig vernieuwd en er zijn nieuwe onderzoeksmethoden toegevoegd.",
        image: "/images/phasmo.jpg"
      }
    ];

    const mockReleases = [
      {
        id: 1,
        title: "Grand Theft Auto VI",
        releaseDate: "13-6-2025",
        platform: "PS5, Xbox Series X, PC",
        price: "€69.99"
      },
      {
        id: 2,
        title: "Fortnite: Mythical Legends Season",
        releaseDate: "13-6-2025",
        platform: "PS5, Xbox Series X, PC, Switch, Mobile",
        price: "Gratis (Battle Pass: €9.99)"
      },
      {
        id: 3,
        title: "Phasmophobia 2.0",
        releaseDate: "13-6-2025",
        platform: "PC, VR",
        price: "Gratis voor huidige eigenaars"
      }
    ];

    setNews(mockNews);
    setUpcomingReleases(mockReleases);
    setLoading(false);
  }, []);

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  return (
    <>
      <Header />
      <div className="news-container">
        <h1>Gaming Nieuws & Updates</h1>
        
        <section className="news-section">
          <h2>Laatste Gaming Nieuws</h2>
          <div className="news-grid">
            {news.map((item) => (
              <article key={item.id} className="news-card">
                <img src={item.image} alt={item.title} />
                <div className="news-content">
                  <h3>{item.title}</h3>
                  <p className="date">Datum: {item.date}</p>
                  <p>{item.summary}</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="releases-section">
          <h2>Release Details</h2>
          <div className="releases-list">
            {upcomingReleases.map((release) => (
              <div key={release.id} className="release-card">
                <h3>{release.title}</h3>
                <p>Release Datum: {release.releaseDate}</p>
                <p>Platforms: {release.platform}</p>
                <p className="price">Prijs: {release.price}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </>
  );
};

export default News; 