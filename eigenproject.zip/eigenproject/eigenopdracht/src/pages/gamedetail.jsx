import React from 'react';
import { useParams, Link } from 'react-router-dom';
import gamesData from '../data/games.json';

const GameDetail = () => {
  const { id } = useParams();
  const game = gamesData.find(g => g.id === id);

  if (!game) return <div className="container mt-5">Game niet gevonden.</div>;

  return (
    <>
      <nav className="navbar navbar-expand-lg navbar-light bg-light" style={{ marginBottom: '30px' }}>
        <div className="container">
          <Link className="navbar-brand" to="/" style={{ color: '#000' }}>Game Info</Link>
        </div>
      </nav>

      <div className="container mt-5">
        <Link to="/" className="btn btn-secondary mb-3">← Terug naar overzicht</Link>
        <div className="card p-3">
          <div className="d-flex flex-column align-items-center mb-4">
            <img
              src={game.image}
              alt={game.name}
              style={{ width: '200px', height: '200px', objectFit: 'cover', marginBottom: '20px' }}
            />
     
          </div>


          <div className="d-flex flex-wrap justify-content-between mb-4" style={{ gap: '20px' }}>
            <div><strong>Maker:</strong> {game.maker}</div>
            <div><strong>Releasedatum:</strong> {game.releaseDate}</div>
            <div><strong>Platforms:</strong> {game.platforms}</div>
            <div><strong>Multiplayer:</strong> {game.multiplayer}</div>
            <div><strong>Prijs:</strong> {game.price}</div>
            <div><strong>Categorie:</strong> {game.category}</div>
            <div><strong>Rating:</strong> {game.rating} ⭐</div>
          </div>

          {/* Lange teksten */}
          <div>

            <h4>description</h4>
            <p>{game.description}</p>

            <h4>Over de game</h4>
            <p>{game.details?.over}</p>

            <h4>Gameplay</h4>
            <p>{game.details?.gameplay}</p>

            <h4>Uitgebreide gameplay-info</h4>
            <p>{game.extendedGameplay}</p>

            <h4>Leeftijd</h4>
            <p>{game.details?.leeftijd}</p>
          </div>
          {game.trailerEmbed && (
            <div className="card p-3" style={{ marginTop: '2rem', display: 'flex', flexDirection: 'column', alignItems: 'center', marginBottom: '2.5rem' }}>
              <h4 style={{ textAlign: 'center' }}>Game Trailer</h4>
              <div style={{ display: 'flex', justifyContent: 'center', width: '100%' }}>
                <div style={{ maxWidth: '700px', width: '100%' }}>
                  <div style={{ position: 'relative', paddingBottom: '56.25%', height: 0, overflow: 'hidden' }}>
                    <div style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%' }}
                      dangerouslySetInnerHTML={{ __html: game.trailerEmbed.replace(/width=\"\d+\"/, 'width=\"100%\"').replace(/height=\"\d+\"/, 'height=\"100%\"') }} />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default GameDetail;
