import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Header from '../components/Header';
import quizData from '../data/gameQuizzes.json';
import gamesData from '../data/games.json';
import '../styles/Quiz.css';

const Quiz = () => {
  const { gameId } = useParams();
  const navigate = useNavigate();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showScore, setShowScore] = useState(false);
  const [quiz, setQuiz] = useState(null);
  const [game, setGame] = useState(null);

  useEffect(() => {
    // Find the quiz for the current game
    const currentQuiz = quizData.quizzes.find(q => q.gameId === gameId);
    const currentGame = gamesData.find(g => g.id === gameId);

    if (!currentQuiz || !currentGame) {
      navigate('/'); // Redirect to home if quiz or game not found
      return;
    }

    setQuiz(currentQuiz);
    setGame(currentGame);
  }, [gameId, navigate]);

  const handleAnswerClick = (selectedAnswer) => {
    if (selectedAnswer === quiz.questions[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }

    const nextQuestion = currentQuestion + 1;
    if (nextQuestion < quiz.questions.length) {
      setCurrentQuestion(nextQuestion);
    } else {
      setShowScore(true);
    }
  };

  const handleRestart = () => {
    setCurrentQuestion(0);
    setScore(0);
    setShowScore(false);
  };

  if (!quiz || !game) {
    return <div>Loading...</div>;
  }

  return (
    <div className="quiz-page">
      <Header />
      <div className="quiz-container">
        <h1>Quiz: {game.name}</h1>
        
        {showScore ? (
          <div className="score-section">
            <h2>Quiz Afgelopen!</h2>
            <p>Je score: {score} van de {quiz.questions.length}</p>
            <button onClick={handleRestart} className="restart-button">
              Quiz Opnieuw
            </button>
            <button onClick={() => navigate('/')} className="home-button">
              Terug naar Home
            </button>
          </div>
        ) : (
          <div className="question-section">
            <div className="question-count">
              <span>Vraag {currentQuestion + 1}</span>/{quiz.questions.length}
            </div>
            <div className="question-text">
              {quiz.questions[currentQuestion].question}
            </div>
            <div className="answer-section">
              {quiz.questions[currentQuestion].options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleAnswerClick(index)}
                  className="answer-button"
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Quiz; 