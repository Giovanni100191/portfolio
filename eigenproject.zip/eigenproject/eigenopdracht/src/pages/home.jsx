import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import GameOfTheDay from '../components/GameOfTheDay';
import gamesData from '../data/games.json';
import '../styles/Home.css';

const Home = () => {
  const [games] = useState(gamesData);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredGames = games.filter(game =>
    game.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    game.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="home">
      <Header />
      <div className="search-container">
        <input
          type="text"
          placeholder="Zoek op naam of categorie..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="search-input"
        />
      </div>

      <GameOfTheDay compact={true} />

      <div className="games-grid">
        {filteredGames.map(game => (
          <div key={game.id} className="game-card">
            <img src={game.image} alt={game.name} className="game-image" />
            <div className="game-info">
              <h3>{game.name}</h3>
              <p className="category">{game.category}</p>
              <p className="description">{game.description}</p>
              <div className="game-details">
                <span className="rating">★ {game.rating}</span>
                <span className="price">{game.price}</span>
              </div>
              <div className="button-container">
                <Link to={`/game/${game.id}`} className="more-info-button">
                  Meer Info
                </Link>
                <Link to={`/quiz/${game.id}`} className="quiz-button">
                  Quiz
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Home;
