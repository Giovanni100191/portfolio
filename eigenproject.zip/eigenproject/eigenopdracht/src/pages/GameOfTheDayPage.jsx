import React from 'react';
import Header from '../components/Header';
import GameOfTheDay from '../components/GameOfTheDay';
import '../styles/GameOfTheDayPage.css';

const GameOfTheDayPage = () => {
  return (
    <>
      <Header />
      <div className="game-of-the-day-page">
        <div className="container">
          <h1 className="page-title">Game van de Dag</h1>
          <div className="main-content">
            <div className="game-section">
              <GameOfTheDay />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default GameOfTheDayPage; 