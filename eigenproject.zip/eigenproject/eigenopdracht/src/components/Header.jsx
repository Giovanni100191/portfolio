import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/Header.css';

const Header = () => {
  return (
    <nav className="main-header">
      <div className="header-container">
        <Link className="header-logo" to="/">Gameobox</Link>
        <div className="header-nav">
          <Link className="header-link" to="/">Home</Link>
          <Link className="header-link" to="/news">Nieuws</Link>
          <Link className="header-link" to="/game-of-the-day">Game van de Dag</Link>
        </div>
      </div>
    </nav>
  );
};

export default Header; 