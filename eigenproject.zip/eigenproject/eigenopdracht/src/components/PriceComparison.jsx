import React, { useState } from 'react';
import '../styles/PriceComparison.css';

const PriceComparison = ({ gameTitle }) => {
  const [prices, setPrices] = useState([
    {
      id: 1,
      retailer: "Steam",
      price: 59.99,
      currency: "EUR",
      inStock: true
    },
    {
      id: 2,
      retailer: "Epic Games Store",
      price: 54.99,
      currency: "EUR",
      inStock: true
    },
    {
      id: 3,
      retailer: "GOG",
      price: 49.99,
      currency: "EUR",
      inStock: true
    }
  ]);

  const formatPrice = (price, currency) => {
    return new Intl.NumberFormat('nl-NL', {
      style: 'currency',
      currency: currency
    }).format(price);
  };

  const lowestPrice = Math.min(...prices.map(p => p.price));

  return (
    <div className="price-comparison">
      <h2>Prijsvergelijking voor {gameTitle}</h2>
      <div className="price-grid">
        {prices.map((retailer) => (
          <div 
            key={retailer.id} 
            className={`price-card ${retailer.price === lowestPrice ? 'lowest-price' : ''}`}
          >
            <h3>{retailer.retailer}</h3>
            <div className="price">
              {formatPrice(retailer.price, retailer.currency)}
              {retailer.price === lowestPrice && (
                <span className="best-price-badge">Beste Prijs!</span>
              )}
            </div>
            <div className="availability">
              {retailer.inStock ? (
                <span className="in-stock">Op voorraad</span>
              ) : (
                <span className="out-of-stock">Niet op voorraad</span>
              )}
            </div>
            <button className="buy-button">
              Koop nu
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PriceComparison; 