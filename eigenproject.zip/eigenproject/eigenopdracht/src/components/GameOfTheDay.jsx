import React, { useState, useEffect } from 'react';
import '../styles/GameOfTheDay.css';

const GameOfTheDay = ({ compact = false }) => {
  const [gameOfTheDay, setGameOfTheDay] = useState({
    title: "Cyber Adventure 2077",
    description: "Een episch open-wereld RPG spel dat zich afspeelt in een futuristische stad.",
    image: "/images/cyberpunk2077.jpg",
    discount: 30,
    originalPrice: 59.99,
    currentPrice: 41.99,
    rating: 4.5,
    releaseDate: "2024-01-15",
    developer: "Future Games Studio",
    publisher: "Gaming Corp"
  });

  const [timeLeft, setTimeLeft] = useState({
    hours: 23,
    minutes: 59,
    seconds: 59
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        let { hours, minutes, seconds } = prev;
        
        if (seconds > 0) {
          seconds--;
        } else {
          seconds = 59;
          if (minutes > 0) {
            minutes--;
          } else {
            minutes = 59;
            if (hours > 0) {
              hours--;
            }
          }
        }

        return { hours, minutes, seconds };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  if (compact) {
    return (
      <div className="game-of-the-day compact">
        <div className="game-content compact">
          <div className="game-image compact">
            <img src={gameOfTheDay.image} alt={gameOfTheDay.title} />
            <div className="discount-badge">-{gameOfTheDay.discount}%</div>
          </div>
          
          <div className="game-info compact">
            <h2>Game van de Dag</h2>
            <h3>{gameOfTheDay.title}</h3>
            
            <div className="price-info">
              <span className="original-price">€{gameOfTheDay.originalPrice}</span>
              <span className="current-price">€{gameOfTheDay.currentPrice}</span>
            </div>

            <div className="countdown compact">
              <p>Aanbieding eindigt over:</p>
              <div className="timer">
                <span>{String(timeLeft.hours).padStart(2, '0')}</span>:
                <span>{String(timeLeft.minutes).padStart(2, '0')}</span>:
                <span>{String(timeLeft.seconds).padStart(2, '0')}</span>
              </div>
            </div>

            <button className="buy-now-button">Nu Kopen</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="game-of-the-day">
      <div className="game-content">
        <div className="game-image">
          <img src={gameOfTheDay.image} alt={gameOfTheDay.title} />
          <div className="discount-badge">-{gameOfTheDay.discount}%</div>
        </div>
        
        <div className="game-info">
          <h2>Game van de Dag</h2>
          <h3>{gameOfTheDay.title}</h3>
          
          <div className="price-info">
            <span className="original-price">€{gameOfTheDay.originalPrice}</span>
            <span className="current-price">€{gameOfTheDay.currentPrice}</span>
          </div>

          <div className="countdown">
            <p>Aanbieding eindigt over:</p>
            <div className="timer">
              <span>{String(timeLeft.hours).padStart(2, '0')}</span>:
              <span>{String(timeLeft.minutes).padStart(2, '0')}</span>:
              <span>{String(timeLeft.seconds).padStart(2, '0')}</span>
            </div>
          </div>

          <p className="description">{gameOfTheDay.description}</p>
          
          <div className="game-details">
            <div className="detail">
              <span className="label">Ontwikkelaar:</span>
              <span>{gameOfTheDay.developer}</span>
            </div>
            <div className="detail">
              <span className="label">Uitgever:</span>
              <span>{gameOfTheDay.publisher}</span>
            </div>
            <div className="detail">
              <span className="label">Release Datum:</span>
              <span>{new Date(gameOfTheDay.releaseDate).toLocaleDateString('nl-NL')}</span>
            </div>
            <div className="detail">
              <span className="label">Beoordeling:</span>
              <span className="rating">★ {gameOfTheDay.rating}/5</span>
            </div>
          </div>

          <button className="buy-now-button">Nu Kopen</button>
        </div>
      </div>
    </div>
  );
};

export default GameOfTheDay; 