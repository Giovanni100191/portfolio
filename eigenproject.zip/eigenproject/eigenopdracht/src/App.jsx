import { Routes, Route } from 'react-router-dom';
import Home from './pages/home';
import GameDetail from './pages/gamedetail';
import News from './pages/News';
import GameOfTheDayPage from './pages/GameOfTheDayPage';
import Quiz from './pages/Quiz';
import './App.css';

const App = () => {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/game/:id" element={<GameDetail />} />
      <Route path="/news" element={<News />} />
      <Route path="/game-of-the-day" element={<GameOfTheDayPage />} />
      <Route path="/quiz/:gameId" element={<Quiz />} />
    </Routes>
  );
};

export default App;
