Voor het opstarten  

 

cd eigenopdracht 

Npm install 

Npm run dev 