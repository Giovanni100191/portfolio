<?php
session_start();
require_once 'config.php';

$message = ''; // Variable to store the login error message

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = getDB();  // Get the PDO instance from config.php
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the user exists in the database
    $stmt = $pdo->prepare("SELECT * FROM bezorg_app_accounts WHERE username = :username");
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        // Set session variables for the logged-in user
        $_SESSION['user'] = [
            'id' => $user['id'],
            'username' => $user['username'],
            'role' => $user['role']
        ];
        // Redirect to the dashboard page after successful login
        header('Location: index.php');
        exit;
    } else {
        // If login fails, set an error message
        $message = 'Onjuiste gebruikersnaam of wachtwoord.';
    }
}

include 'views/login_view.php';  // Include the login view (HTML form) for rendering
?>
