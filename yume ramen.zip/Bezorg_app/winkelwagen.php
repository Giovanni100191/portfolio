<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? null;
    $id = $_POST['id'] ?? null;

    if ($action !== null && $id !== null && isset($_SESSION['cart'][$id])) {
        if ($action === 'increase') {
            $_SESSION['cart'][$id]['quantity']++;
        } elseif ($action === 'decrease') {
            $_SESSION['cart'][$id]['quantity']--;

            // Verwijder item als hoeveelheid 0 is
            if ($_SESSION['cart'][$id]['quantity'] <= 0) {
                unset($_SESSION['cart'][$id]);
            }
        }
    }
    echo json_encode(['success' => true, 'cart' => $_SESSION['cart']]);
    exit;
}

// Bereken totaal en haal winkelwagenitems op
$cartItems = $_SESSION['cart'] ?? [];
$totalPrice = 0;

foreach ($cartItems as $item) {
    $totalPrice += $item['prijs'] * $item['quantity'];
}

// Zorg ervoor dat de hoeveelheden worden weergegeven bij afrekenen
$_SESSION['checkout_cart'] = $cartItems;

// Include de view
include 'views/winkelwagen_view.php';
?>
