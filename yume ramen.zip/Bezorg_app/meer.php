<?php
session_start();
require_once 'config.php';

include 'views/meer_view.php';
?>
