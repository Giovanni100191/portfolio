<?php
include 'config.php';
$pdo = getDB();

$sql = "SELECT * FROM bezorg_app_gerechten";  // Gebruik de bezorg_app_gerechten tabel
$stmt = $pdo->query($sql);
$gerechten = $stmt->fetchAll(PDO::FETCH_ASSOC);

include 'views/menu_view.php';
?>