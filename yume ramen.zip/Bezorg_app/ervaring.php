<?php
session_start();
include 'config.php';

// Verbind met de database
$pdo = getDB();

// Verwerk formulier als het ingediend is
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $naam = $_POST['naam'] ?? null;
    $email = $_POST['email'] ?? null;
    $review_text = $_POST['review_text'] ?? null;
    $rating = $_POST['rating'] ?? null;

    // Validatie van de invoer
    if (!$naam || !$email || !$review_text || !$rating || $rating < 1 || $rating > 5) {
        $error = "Vul alle velden correct in.";
    } else {
        // Sla review op in de database
        $stmt = $pdo->prepare("INSERT INTO bezorg_app_reviews (naam, email, review_text, rating) VALUES (?, ?, ?, ?)");
        $stmt->execute([$naam, $email, $review_text, $rating]);

        // Redirect na succesvolle inzending
        header("Location: ervaring.php");
        exit();  // Stop verdere uitvoering van de code
    }
}

// Haal alle reviews op
$stmt = $pdo->query("SELECT * FROM bezorg_app_reviews ORDER BY created_at DESC");
$reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Include de view
include 'views/ervaring_view.php';
?>
