<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bezorger - Bestellingen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .card { margin-bottom: 1rem; }
        .badge-product { font-size: 0.9rem; }
    </style>
</head>
<body>
<main class="container my-4">
    <h1 class="text-center fw-bold mb-4">Bezorger - Bestellingen</h1>

    <?php if (empty($bestellingen)): ?>
        <div class="alert alert-info text-center">Er zijn momenteel geen bestellingen.</div>
    <?php else: ?>
        <div class="row">
            <?php foreach ($bestellingen as $bestelling): ?>
                <div class="col-12 col-md-6">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title fw-bold">Bestelling ID: <?= htmlspecialchars($bestelling['id']) ?></h5>
                            <p class="card-text mb-1"><strong>Naam:</strong> <?= htmlspecialchars($bestelling['naam']) ?></p>
                            <p class="card-text mb-1"><strong>Adres:</strong> <?= htmlspecialchars($bestelling['adres']) ?> <?= htmlspecialchars($bestelling['huisnummer']) ?></p>
                            <p class="card-text mb-1"><strong>Postcode:</strong> <?= htmlspecialchars($bestelling['postcode']) ?></p>
                            <p class="card-text mb-1"><strong>Telefoonnummer:</strong> <?= htmlspecialchars($bestelling['telefoonnummer']) ?></p>
                            <p><strong>Producten:</strong></p>
                            <ul class="list-unstyled mb-3">
                                <?php
                                $producten = json_decode($bestelling['producten'], true);
                                if (is_array($producten)) {
                                    foreach ($producten as $product) {
                                        $productNaam = htmlspecialchars($product['naam'] ?? 'Onbekend product');
                                        $productAantal = htmlspecialchars($product['aantal'] ?? 'Onbekend aantal');
                                        echo "<li><span class='badge bg-primary badge-product'>{$productNaam}</span> 
                                              <span class='text-muted'>(Aantal: {$productAantal})</span></li>";
                                    }
                                } else {
                                    echo "<li><span class='text-danger'>Geen producten gevonden.</span></li>";
                                }
                                ?>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>
<?php include 'shared/nav_bar.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
