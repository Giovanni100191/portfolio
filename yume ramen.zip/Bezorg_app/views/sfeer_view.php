<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/sfeer.css">
    <title>Sfeer</title>
</head>
<body>
<div class="container my-5">
    <div class="text-center mb-4">
        <h2 class="fw-bold">Sfeer</h2>
        <p class="japanese-text">雰囲気</p>
    </div>

    <!-- Over Japan -->
    <div class="row align-items-center mb-5">
        <div class="col-md-6">
            <h3 class="fw-bold">Over Japan</h3>
            <p>
                Japan, bekend als "Nihon" of "Nippon" in het Japans (日本), is een eilandstaat in Oost-Azië. Het land bestaat uit
                vier grote eilanden en duizenden kleinere eilanden. Japan staat bekend om zijn rijke cultuur, technologische
                innovaties en natuurlijke schoonheid.
            </p>
        </div>
        <div class="col-md-6">
            <img src="images/japan.jpg" alt="Japan landschap" class="img-fluid shadow">
        </div>
    </div>

    <!-- Sfeer -->
    <div class="row align-items-center mb-5">
        <div class="col-md-6">
            <h3 class="fw-bold">Sfeer</h3>
            <p>
                De sfeer in Japan is een harmonieuze mix van traditie en moderniteit. Historische tempels staan naast moderne
                steden en de natuur speelt een belangrijke rol in de cultuur van het land.
            </p>
        </div>
        <div class="col-md-6">
            <img src="images/japan_sfeer.jpg" alt="Sfeer" class="img-fluid shadow">
        </div>
    </div>

    <!-- Geschiedenis van Ramen -->
    <div class="row align-items-center mb-5">
        <div class="col-md-6">
            <h3 class="fw-bold">Geschiedenis van Ramen</h3>
            <p>
                Ramen is een populair gerecht in Japan, oorspronkelijk afkomstig uit China. Het werd in de late 19e eeuw
                geïntroduceerd en is nu een icoon van de Japanse keuken.
            </p>
        </div>
        <div class="col-md-6">
            <img src="images/ramen_sfeer.jpg" alt="Ramen" class="img-fluid shadow">
        </div>
    </div>

    <!-- Geschiedenis van Soba -->
    <div class="row align-items-center mb-5">
        <div class="col-md-6">
            <h3 class="fw-bold">Geschiedenis van Soba</h3>
            <p>
                Soba is een traditioneel gerecht gemaakt van boekweitmeel, populair sinds de Edo-periode (1603-1868).
                Het wordt koud geserveerd met dipsaus of warm in een bouillon.
            </p>
        </div>
        <div class="col-md-6">
            <img src="images/soba.jpg" alt="Soba" class="img-fluid shadow">
        </div>
    </div>

    <!-- Geschiedenis van Udon -->
    <div class="row align-items-center mb-5">
        <div class="col-md-6">
            <h3 class="fw-bold">Geschiedenis van Udon</h3>
            <p>
                Udon, gemaakt van tarwe, is een stevige noedelsoort die vaak in warme bouillon wordt geserveerd. Het is
                comfortfood voor veel Japanners.
            </p>
        </div>
        <div class="col-md-6">
            <img src="images/udon.jpg" alt="Udon" class="img-fluid shadow">
        </div>
    </div>
</div>
<?php include 'shared/nav_bar.php'; ?>
</body>
</html>
