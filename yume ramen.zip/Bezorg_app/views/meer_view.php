<?php
session_start(); // Start the session to check if the user is logged in
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/meer.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Meer</title>
</head>
<body>
<div class="container mt-4">
    <!-- Header -->
    <div class="text-center">
        <h1 class="fw-bold">Meer</h1>
        <p class="japanese-text">もっと</p>
    </div>

    <!-- Navigatieknoppen -->
    <div class="list-group mt-4">
        <?php if (isset($_SESSION['user'])): ?>
            <!-- Display "Logout" button if user is logged in -->
            <a href="logout.php" class="list-group-item list-group-item-action d-flex align-items-center">
                <i class="bi bi-box-arrow-right me-2"></i> Logout
            </a>

            <!-- Display "Bestellingen" button if user role is 'kok' or 'admin' -->
            <?php if ($_SESSION['user']['role'] === 'kok' || $_SESSION['user']['role'] === 'admin'): ?>
                <a href="kok.php" class="list-group-item list-group-item-action d-flex align-items-center">
                    <i class="bi bi-list-check me-2"></i> Bestellingen
                </a>
            <?php endif; ?>

            <!-- Display "Bezorgingen" button if user role is 'bezorger' or 'admin' -->
            <?php if ($_SESSION['user']['role'] === 'bezorger' || $_SESSION['user']['role'] === 'admin'): ?>
                <a href="bezorger.php" class="list-group-item list-group-item-action d-flex align-items-center">
                    <i class="bi bi-truck me-2"></i> Bezorgingen
                </a>
            <?php endif; ?>

        <?php else: ?>
            <!-- Display "Login" link if user is not logged in -->
            <a href="login.php" class="list-group-item list-group-item-action d-flex align-items-center">
                <i class="bi bi-person-circle me-2"></i> Login/Maak een account
            </a>
        <?php endif; ?>

        <a href="contact.php" class="list-group-item list-group-item-action d-flex align-items-center">
            <i class="bi bi-envelope me-2"></i> Contact
        </a>
        <a href="ervaring.php" class="list-group-item list-group-item-action d-flex align-items-center">
            <i class="bi bi-chat-left-text me-2"></i> Ervaring
        </a>
    </div>
</div>

<?php include 'shared/nav_bar.php'; ?>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
