<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kok - Overzicht van Bestellingen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .badge-product {
            font-size: 0.85rem;
            margin-right: 5px;
        }
    </style>
</head>
<body>
<main>
    <div class="container mt-4">
        <div class="text-center mb-4">
            <h2 class="fw-bold">Overzicht van Bestellingen</h2>
            <p class="text-muted">Bekijk welke gerechten moeten worden bereid.</p>
        </div>

        <?php if (empty($bestellingen)): ?>
            <div class="alert alert-info text-center">
                Er zijn momenteel geen bestellingen.
            </div>
        <?php else: ?>
            <div class="accordion" id="ordersAccordion">
                <?php foreach ($bestellingen as $bestelling): ?>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="heading<?= $bestelling['id'] ?>">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                    data-bs-target="#collapse<?= $bestelling['id'] ?>" aria-expanded="false"
                                    aria-controls="collapse<?= $bestelling['id'] ?>">
                                Bestelling #<?= htmlspecialchars($bestelling['id']) ?> - <?= htmlspecialchars($bestelling['naam']) ?>
                            </button>
                        </h2>
                        <div id="collapse<?= $bestelling['id'] ?>" class="accordion-collapse collapse"
                             aria-labelledby="heading<?= $bestelling['id'] ?>" data-bs-parent="#ordersAccordion">
                            <div class="accordion-body">
                                <p><strong>Naam:</strong> <?= htmlspecialchars($bestelling['naam']) ?></p>
                                <p><strong>Adres:</strong> <?= htmlspecialchars($bestelling['adres']) ?>, <?= htmlspecialchars($bestelling['huisnummer']) ?></p>
                                <p><strong>Postcode:</strong> <?= htmlspecialchars($bestelling['postcode']) ?></p>
                                <p><strong>Telefoonnummer:</strong> <?= htmlspecialchars($bestelling['telefoonnummer']) ?></p>
                                <p><strong>Datum:</strong> <?= htmlspecialchars($bestelling['created_at']) ?></p>
                                <p><strong>Producten:</strong></p>
                                <ul class="list-unstyled mb-0">
                                    <?php
                                    $producten = json_decode($bestelling['producten'], true);
                                    if (is_array($producten)) {
                                        foreach ($producten as $product) {
                                            $productNaam = htmlspecialchars($product['naam'] ?? 'Onbekend product');
                                            $productAantal = htmlspecialchars($product['aantal'] ?? 'Onbekend aantal');
                                            $productPrijs = htmlspecialchars($product['prijs'] ?? '0.00');
                                            $subtotaal = number_format($productPrijs * $productAantal, 2);
                                            echo "<li><span class='badge bg-primary badge-product'>{$productNaam}</span> 
                  <span class='text-muted'>(Aantal: {$productAantal}, Subtotaal: €{$subtotaal})</span></li>";
                                        }
                                    } else {
                                        echo "<li><span class='text-danger'>Geen producten gevonden.</span></li>";
                                    }
                                    ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</main>
<?php include 'shared/nav_bar.php'; ?>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
