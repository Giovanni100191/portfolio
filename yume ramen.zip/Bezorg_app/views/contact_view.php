<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/contact.css" rel="stylesheet">
    <title>Contactpagina</title>
</head>
<body>
<div class="container py-5">
    <?php if ($message_sent): ?>
        <div class="alert alert-success alert-dismissible fade show notification" role="alert">
            Mail is succesvol verzonden!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php elseif ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show notification" role="alert">
            <?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="contact-form mx-auto p-4">
        <div class="text-center mb-4">
            <h2 class="fw-bold">Contact</h2>
            <p class="japanese-text">接触</p>
        </div>
        <form action="contact.php" method="POST" class="needs-validation" novalidate>
            <div class="mb-3">
                <label for="email" class="form-label">E-mail</label>
                <input type="email" class="form-control" id="email" name="email" required>
                <div class="invalid-feedback">Voer een geldig e-mailadres in.</div>
            </div>
            <div class="mb-3">
                <label for="name" class="form-label">Naam</label>
                <input type="text" class="form-control" id="name" name="name" required>
                <div class="invalid-feedback">Naam is verplicht.</div>
            </div>
            <div class="mb-3">
                <label for="message" class="form-label">Bericht</label>
                <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                <div class="invalid-feedback">Bericht mag niet leeg zijn.</div>
            </div>
            <button type="submit" class="btn btn-primary w-100">Versturen</button>
        </form>
    </div>
</div>

<footer class="footer mt-5">
    <div class="text-center text-white py-3">
        <p>Contact</p>
        <p>Tel: <a href="tel:+31642994332" class="text-white">+31 6 42994332</a></p>
        <p>E-mail: <a href="mailto:100884@glr.nl" class="text-white">100884@glr.nl or/of 100191@glr.nl</a></p>
        <p>Locatie: Rotterdam, Nederland</p>
    </div>
</footer>
<?php include 'shared/nav_bar.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Bootstrap Validatie
    (function () {
        'use strict';
        const forms = document.querySelectorAll('.needs-validation');
        Array.from(forms).forEach(form => {
            form.addEventListener('submit', event => {
                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                form.classList.add('was-validated');
            }, false);
        });
    })();

    // Timer om notificatie na 4 seconden te laten verdwijnen
    const notification = document.querySelector('.notification');
    if (notification) {
        setTimeout(() => {
            notification.classList.add('fade-out');
            setTimeout(() => notification.remove(), 1000);
        }, 4000);
    }
</script>
</body>
</html>
