<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bezorg App - Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/index.css" rel="stylesheet">
</head>
<body>
<main>
    <div class="container-fluid p-0">
        <div class="container text-center mt-4">
            <h1 class="fw-bold">Yume Restaurant</h1>
            <p class="jap-text">夢レストラン</p>
        </div>
        <div class="text-center order-btn">
            <a href="menu.php" class="btn btn-order btn-lg">Bestel Nu</a>
        </div>
    </div>

    <div class="container card-container">
        <!-- Dynamische kaarten -->
        <?php foreach ($cards as $card): ?>
            <a href="<?= htmlspecialchars($card['link']) ?>" class="card-link">
                <div class="card">
                    <img src="<?= htmlspecialchars($card['image']) ?>" class="card-img-top" alt="<?= htmlspecialchars($card['title']) ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($card['title']) ?></h5>
                        <p class="card-text"><?= htmlspecialchars($card['description']) ?></p>
                    </div>
                </div>
            </a>
        <?php endforeach; ?>
    </div>
</main>

<?php include 'shared/nav_bar.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
