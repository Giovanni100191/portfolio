<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bestel Gerechten - Ramen Restaurant</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/menu.css">  <!-- Koppelen van de CSS -->
</head>
<body>
<main>
    <div class="container">

        <div class="text-center mb-4">
            <h2 class="fw-bold">Menu & deals</h2>
            <p class="japanese-text">メニューとお得な情報</p>
        </div>

        <!-- Zoekbalk met groter kruisje -->
        <div class="mb-4 search-wrapper">
            <input type="text" id="searchInput" class="form-control" placeholder="Zoek naar gerechten..." onkeyup="filterMenu()">
            <span id="clearSearch" onclick="clearSearch()">×</span>
        </div>

        <div class="row" id="menuItems">
            <?php foreach ($gerechten as $gerecht): ?>
                <div class="col-md-4 menu-item">
                    <div class="card mb-4">
                        <img src="<?= htmlspecialchars($gerecht['afbeelding']) ?>" class="card-img-top" alt="<?= htmlspecialchars($gerecht['naam']) ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($gerecht['naam']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($gerecht['beschrijving']) ?></p>
                            <p class="card-text"><strong>Prijs: €<?= number_format($gerecht['prijs'], 2) ?></strong></p>
                            <div class="d-flex justify-content-between">
                                <a href="winkelwagen.php?id=<?= $gerecht['id'] ?>" class="btn btn-primary">Bestel</a>
                                <button class="btn btn-secondary add-to-cart" data-id="<?= $gerecht['id'] ?>">+</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</main>

<?php include 'shared/nav_bar.php'; ?>

<script src="js/menu.js"></script>  <!-- Koppelen van de JavaScript -->

</body>
</html>
