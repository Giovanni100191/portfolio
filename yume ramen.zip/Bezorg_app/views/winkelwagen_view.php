<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Winkelwagen - Ramen Restaurant</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/winkelwagen.css">
</head>
<body>
<main>
    <div class="container mt-4">
        <div class="text-center mb-4">
            <h2 class="fw-bold">Bestel</h2>
            <p class="japanese-text">注文</p>
        </div>
        <h3 class="fw-bold mb-4">Winkelwagen</h3>

        <?php if (empty($cartItems)): ?>
            <p class="text-muted">Je winkelwagen is leeg. <a href="menu.php">Ga terug naar het menu</a>.</p>
        <?php else: ?>
            <table class="table table-bordered text-center align-middle">
                <thead class="table-dark">
                <tr>
                    <th>Gerecht</th>
                    <th>Aantal</th>
                    <th>Prijs per stuk</th>
                    <th>Subtotaal</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($cartItems as $id => $item): ?>
                    <tr data-id="<?= $id ?>">
                        <td><?= htmlspecialchars($item['naam']) ?></td>
                        <td>
                            <div class="d-flex justify-content-center align-items-center">
                                <button class="btn btn-sm btn-danger me-2 btn-decrease">-</button>
                                <span class="fw-bold"><?= htmlspecialchars($item['quantity']) ?></span>
                                <button class="btn btn-sm btn-success ms-2 btn-increase">+</button>
                            </div>
                        </td>
                        <td>€<?= number_format($item['prijs'], 2) ?></td>
                        <td>€<?= number_format($item['prijs'] * $item['quantity'], 2) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <div class="text-end">
                <h4 class="fw-bold">Totaal: €<?= number_format($totalPrice, 2) ?></h4>
            </div>
            <div class="d-flex justify-content-between mt-3">
                <a href="menu.php" class="btn btn-secondary">Verder winkelen</a>
                <a href="afrekenen.php" class="btn btn-primary">Afrekenen</a>
            </div>
        <?php endif; ?>
    </div>
</main>
<?php include 'shared/nav_bar.php'; ?>
<script src="js/winkelwagen.js"></script>
</body>
</html>
