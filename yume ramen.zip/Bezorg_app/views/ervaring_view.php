<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laat een Review Achter</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .stars {
            display: flex;
            justify-content: space-between;
            width: 120px;
        }
        .star {
            font-size: 1.5rem;
            cursor: pointer;
        }
    </style>
</head>
<body>

<main class="container mt-5">
    <h1 class="text-center">Laat een Review Achter</h1>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php elseif (!empty($success)): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <!-- Review Formulier -->
    <form method="POST">
        <div class="mb-3">
            <label for="naam" class="form-label">Jouw Naam</label>
            <input type="text" class="form-control" id="naam" name="naam" required>
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">Jouw E-mail</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>

        <div class="mb-3">
            <label for="review_text" class="form-label">Jouw Review</label>
            <textarea class="form-control" id="review_text" name="review_text" rows="4" required></textarea>
        </div>

        <div class="mb-3">
            <label for="rating" class="form-label">Beoordeling</label>
            <div class="stars" id="star-rating">
                <span class="star" data-rating="1">&#9733;</span>
                <span class="star" data-rating="2">&#9733;</span>
                <span class="star" data-rating="3">&#9733;</span>
                <span class="star" data-rating="4">&#9733;</span>
                <span class="star" data-rating="5">&#9733;</span>
            </div>
            <input type="hidden" id="rating" name="rating">
        </div>

        <button type="submit" class="btn btn-primary">Verstuur Review</button>
    </form>

    <h2 class="mt-5">Recente Reviews</h2>
    <div class="list-group">
        <?php foreach ($reviews as $review): ?>
            <div class="list-group-item">
                <h5 class="fw-bold"><?= htmlspecialchars($review['naam']) ?> <span class="badge bg-warning"><?= $review['rating'] ?> sterren</span></h5>
                <p><?= htmlspecialchars($review['review_text']) ?></p>
                <p><strong>Email:</strong> <?= htmlspecialchars($review['email']) ?></p>
                <small class="text-muted">Geplaatst op: <?= $review['created_at'] ?></small>
            </div>
        <?php endforeach; ?>
    </div>
</main>
<?php include 'shared/nav_bar.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/ervaring.js"></script>
</body>
</html>
