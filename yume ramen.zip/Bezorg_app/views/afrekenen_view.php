<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/afrekenen.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Afrekenen</title>
</head>
<body>
<div class="container mt-4">
    <h1 class="text-center">Afrekenen</h1>

    <?php if (!empty($message)): ?>
        <div class="alert alert-success">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="afrekenen.php">
        <div class="mb-3">
            <label for="name" class="form-label">Naam</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="mb-3">
            <label for="phone" class="form-label">Telefoonnummer</label>
            <input type="text" class="form-control" id="phone" name="phone" required>
        </div>
        <div class="mb-3">
            <label for="address" class="form-label">Adres</label>
            <input type="text" class="form-control" id="address" name="address" required>
        </div>
        <div class="mb-3">
            <label for="postcode" class="form-label">Postcode</label>
            <input type="text" class="form-control" id="postcode" name="postcode" required>
        </div>
        <div class="mb-3">
            <label for="huisnummer" class="form-label">Huisnummer</label>
            <input type="text" class="form-control" id="huisnummer" name="huisnummer" required>
        </div>

        <h3>Uw Winkelwagen</h3>
        <ul class="list-group mb-3">
            <?php if (!empty($_SESSION['cart'])): ?>
                <?php foreach ($_SESSION['cart'] as $item): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <?= htmlspecialchars($item['naam']) ?>
                        <span>€<?= number_format($item['prijs'], 2) ?> x <?= htmlspecialchars($item['quantity']) ?></span>
                    </li>
                <?php endforeach; ?>
            <?php else: ?>
                <li class="list-group-item">Uw winkelwagen is leeg.</li>
            <?php endif; ?>
        </ul>

        <button type="submit" class="btn btn-primary">Bestelling Plaatsen</button>
    </form>
</div>
<?php include 'shared/nav_bar.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
