<?php
session_start(); // Start the session
session_destroy(); // Destroy all session data to log the user out
header('Location: meer.php'); // Redirect back to the "Meer" page or any other page you choose
exit();
?>
