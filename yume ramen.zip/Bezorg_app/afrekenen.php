<?php
session_start();
require_once 'config.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verkrijg de invoer van het formulier
    $naam = $_POST['name'];
    $adres = $_POST['address'];
    $postcode = $_POST['postcode'];
    $huisnummer = $_POST['huisnummer'];
    $telefoonnummer = $_POST['phone'];

    // Verkrijg de producten uit de winkelwagen
    $producten = $_SESSION['cart'] ?? [];

    // Verkrijg de user_id uit de sessie
    $userId = $_SESSION['user']['id'] ?? null; // user_id kan null zijn als de gebruiker niet ingelogd is

    // Maak een array van bestelde producten
    $productenArray = [];
    foreach ($producten as $item) {
        $productenArray[] = [
            'naam' => $item['naam'],
            'prijs' => $item['prijs'],
            'aantal' => $item['quantity']
        ];
    }

    // Converteer de producten naar JSON
    $productenJson = json_encode($productenArray);

    // Bereid de SQL-query voor om de bestelling in te voegen
    try {
        $pdo = getDB();
        $stmt = $pdo->prepare("
            INSERT INTO bezorg_app_bestelling (naam, adres, postcode, huisnummer, telefoonnummer, producten, user_id, created_at) 
            VALUES (:naam, :adres, :postcode, :huisnummer, :telefoonnummer, :producten, :user_id, :created_at)
        ");
        $stmt->execute([
            ':naam' => $naam,
            ':adres' => $adres,
            ':postcode' => $postcode,
            ':huisnummer' => $huisnummer,
            ':telefoonnummer' => $telefoonnummer,
            ':producten' => $productenJson,
            ':user_id' => $userId, // De user_id wordt hier toegevoegd (kan NULL zijn als de gebruiker niet ingelogd is)
            ':created_at' => date('Y-m-d H:i:s'),
        ]);

        // Leeg de winkelwagen na bestelling
        unset($_SESSION['cart']);
        $message = 'Uw bestelling is succesvol geplaatst!';
    } catch (PDOException $e) {
        $message = "Fout bij het opslaan in de database: " . $e->getMessage();
    }
}

include 'views/afrekenen_view.php';
?>
