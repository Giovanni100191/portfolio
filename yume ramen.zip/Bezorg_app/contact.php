<?php

// Controleren of het formulier is verzonden
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $name = $_POST['name'] ?? '';
    $message = $_POST['message'] ?? '';

    // Validatie
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Ongeldig e-mailadres.";
        exit;
    }

    if (empty($name) || empty($message)) {
        echo "Naam en bericht zijn verplicht.";
        exit;
    }

    $to = "100884@glr.nl, 100191@glr.nl"; // Meerdere ontvangers, gescheiden door komma's
    $subject = "Nieuw bericht van contactformulier";
    $headers = "From: $email\r\n";
    $headers .= "Reply-To: $email\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    $body = "Je hebt een nieuw bericht ontvangen via het contactformulier.\n\n";
    $body .= "Naam: $name\n";
    $body .= "E-mail: $email\n";
    $body .= "Bericht:\n$message\n";

    if (mail($to, $subject, $body, $headers)) {
        echo "Bericht succesvol verzonden!";
    } else {
        echo "Er is een fout opgetreden bij het verzenden van het bericht.";
    }
}


include 'views/contact_view.php';