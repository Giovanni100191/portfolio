<?php

$cards = [
    [
        'image' => 'images/deeljouwervaring.jpg',
        'title' => 'Hoe was je bezoek?',
        'description' => 'Vertel ons hoe jou bezoek was.',
        'link' => 'contact.php'
    ],
    [
        'image' => 'images/deals_menu.jpg',
        'title' => 'Menu en deals',
        'description' => 'Bekijk de nieuwste deals en het gehele menu.',
        'link' => 'menu.php'
    ],
    [
        'image' => 'images/ramen1.jpg',
        'title' => 'De top 5',
        'description' => 'De meest bestelde gerechten van de maand.',
        'link' => 'top5.php'
    ],
];


include 'views/index_view.php';
