<?php
require_once 'config.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = getDB();
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = 'user'; // Standaardrol is 'user'

    // Controleer of de gebruikersnaam of e-mail al bestaat
    $stmt = $pdo->prepare("SELECT * FROM bezorg_app_accounts WHERE username = :username OR email = :email");
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $message = 'Gebruikersnaam of e-mailadres is al in gebruik.';
    } else {
        // Voeg de gebruiker toe
        $stmt = $pdo->prepare("INSERT INTO bezorg_app_accounts (username, password, email, role) VALUES (:username, :password, :email, :role)");
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $password);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':role', $role);

        if ($stmt->execute()) {
            header('Location: login.php'); // Verwijs naar de loginpagina
            exit;
        } else {
            $message = 'Er is iets misgegaan. Probeer het opnieuw.';
        }
    }
}

include 'views/aanmaak_view.php';
?>
