<?php
session_start();
include 'config.php';

// Verbind met de database
$pdo = getDB();

// Haal alle bestellingen op
$sql = "SELECT * FROM bezorg_app_bestelling ORDER BY created_at DESC";
$stmt = $pdo->query($sql);
$bestellingen = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Include de view
include 'views/bezorger_view.php';
?>
