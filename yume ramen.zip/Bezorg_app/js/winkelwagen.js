 document.addEventListener('DOMContentLoaded', () => {
        const cartItems = document.querySelector('tbody');

        cartItems.addEventListener('click', (e) => {
            if (e.target.classList.contains('btn-increase') || e.target.classList.contains('btn-decrease')) {
                const row = e.target.closest('tr');
                const itemId = row.dataset.id;
                const action = e.target.classList.contains('btn-increase') ? 'increase' : 'decrease';

                fetch('winkelwagen.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({ action, id: itemId })
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            location.reload();
                        } else {
                            console.error('Fout bij het updaten van de winkelwagen:', data.error);
                        }
                    })
                    .catch(error => console.error('AJAX-fout:', error));
            }
        });
    });