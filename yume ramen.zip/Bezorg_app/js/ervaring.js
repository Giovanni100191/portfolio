// Sterrenrating functionaliteit
const stars = document.querySelectorAll('.star');
const ratingInput = document.getElementById('rating');

stars.forEach(star => {
    star.addEventListener('click', function () {
        const rating = this.getAttribute('data-rating');
        ratingInput.value = rating;
        stars.forEach(s => s.style.color = ''); // Reset alle sterren
        for (let i = 0; i < rating; i++) {
            stars[i].style.color = 'gold'; // Markeer geselecteerde sterren
        }
    });
});