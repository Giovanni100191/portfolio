document.addEventListener('DOMContentLoaded', function () {
    // Bootstrap validatie
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });

    // Timer voor notificatie verwijderen
    const notification = document.querySelector('.notification-wrapper');
    if (notification) {
        setTimeout(() => {
            notification.classList.remove('show');
        }, 4000); // Na 4 seconden
    }
});
