document.addEventListener('DOMContentLoaded', () => {
    const buttons = document.querySelectorAll('.add-to-cart');

    buttons.forEach(button => {
        button.addEventListener('click', () => {
            const id = button.dataset.id;

            // Verstuur een fetch POST-verzoek naar de backend
            fetch('add_to_card.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ id: id }), // Verstuur het ID van het gerecht
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                    } else {
                    }
                })
                .catch(error => {
                    console.error('Fout bij het toevoegen aan de winkelwagen:', error);
                });
        });
    });
});


// Functie om het menu te filteren op basis van zoekterm
function filterMenu() {
    let input = document.getElementById('searchInput').value.toLowerCase();
    let menuItems = document.getElementsByClassName('menu-item');

    for (let i = 0; i < menuItems.length; i++) {
        let itemName = menuItems[i].getElementsByClassName('card-title')[0].textContent.toLowerCase();
        if (itemName.includes(input)) {
            menuItems[i].style.display = '';
        } else {
            menuItems[i].style.display = 'none';
        }

        // Toon of verberg het kruisje afhankelijk van de zoekterm
        if (input.length > 0) {
            document.getElementById('clearSearch').style.display = 'block';
        } else {
            document.getElementById('clearSearch').style.display = 'none';
        }
    }
}

// Functie om de zoekbalk te wissen
function clearSearch() {
    document.getElementById('searchInput').value = '';
    filterMenu(); // Roep de filterfunctie opnieuw aan om de producten weer zichtbaar te maken
}
