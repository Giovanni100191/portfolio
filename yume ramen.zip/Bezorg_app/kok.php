<?php
// Toon foutmeldingen
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'config.php';

$pdo = getDB();

// Haal de bestellingen op
$sql = "SELECT * FROM bezorg_app_bestelling ORDER BY created_at DESC";
$stmt = $pdo->query($sql);

$bestellingen = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Toon de view
include 'views/kok_view.php';
?>
