<?php
session_start();
header('Content-Type: application/json');
include 'config.php';

// Controleer of het script correct is opgeroepen
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Ongeldige verzoekmethode.']);
    exit;
}

// Haal de inkomende gegevens op
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['id'])) {
    echo json_encode(['success' => false, 'message' => 'Geen ID opgegeven.']);
    exit;
}

$id = intval($data['id']);

// Verbind met de database
$pdo = getDB();

// Haal het gerecht op
$sql = "SELECT * FROM bezorg_app_gerechten WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute(['id' => $id]);
$gerecht = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$gerecht) {
    echo json_encode(['success' => false, 'message' => 'Gerecht niet gevonden.']);
    exit;
}

// Voeg het gerecht toe aan de winkelwagen
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Controleer of het gerecht al in de winkelwagen zit
$found = false;
foreach ($_SESSION['cart'] as &$item) {
    if ($item['id'] == $id) {
        $item['quantity']++;
        $found = true;
        break;
    }
}

if (!$found) {
    $_SESSION['cart'][] = [
        'id' => $gerecht['id'],
        'naam' => $gerecht['naam'],
        'prijs' => $gerecht['prijs'],
        'quantity' => 1,
    ];
}

echo json_encode(['success' => true]);
?>
