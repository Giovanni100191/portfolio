<link rel="stylesheet" href="css/nav_bar.css">
<nav class="navbar navbar-bottom navbar-expand">
    <div class="container-fluid d-flex justify-content-between">
        <div class="nav-item">
            <a href="index.php">
                <img src="images/home.jpg" alt="Home">
                <div>Home</div>
            </a>
        </div>
        <div class="nav-item">
            <a href="menu.php">
                <img src="images/deals.jpg" alt="Menu">
                <div>Menu</div>
            </a>
        </div>
        <div class="nav-item">
            <a href="winkelwagen.php">
                <img src="images/bestel.jpg" alt="Bestel">
                <div>Bestel</div>
            </a>
        </div>
        <div class="nav-item">
            <a href="sfeer.php">
                <img src="images/sfeer.jpg" alt="Sfeer">
                <div>Sfeer</div>
            </a>
        </div>
        <div class="nav-item">
            <a href="meer.php">
                <img src="images/meer.jpg" alt="Meer">
                <div>Meer</div>
            </a>
        </div>
    </div>
</nav>
