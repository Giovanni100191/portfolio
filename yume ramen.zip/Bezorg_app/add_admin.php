<?php
require_once 'config.php';

$pdo = getDB();

// Admingegevens
$username = '';
$email = '@example.com';
$password = password_hash('', PASSWORD_DEFAULT); // Gebruik een veilige wachtwoordhash
$role = '';

try {
    // Controleer of er al een admin bestaat
    $stmt = $pdo->prepare("SELECT * FROM bezorg_app_accounts WHERE username = :username OR email = :email");
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo "Admin-account bestaat al.";
    } else {
        // Voeg de admin toe
        $stmt = $pdo->prepare("INSERT INTO bezorg_app_accounts (username, password, email, role, created_at) 
                               VALUES (:username, :password, :email, :role, NOW())");
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $password);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':role', $role);

        if ($stmt->execute()) {
            echo "Admin-account succesvol toegevoegd.";
        } else {
            echo "Er is een fout opgetreden bij het toevoegen van de admin.";
        }
    }
} catch (PDOException $e) {
    echo "Fout: " . $e->getMessage();
}
?>
