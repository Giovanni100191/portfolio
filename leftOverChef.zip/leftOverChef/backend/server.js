const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(bodyParser.json());

// Zorg dat database bestaat en initialiseer
const dbFile = path.join(__dirname, 'data.db');
const sqlFile = path.join(__dirname, 'database.sql');

if (!fs.existsSync(dbFile)) {
  const db = new sqlite3.Database(dbFile);
  const sql = fs.readFileSync(sqlFile, 'utf8');
  db.exec(sql, (err) => {
    if (err) throw err;
    db.close();
  });
}

const db = new sqlite3.Database(dbFile);

// Register endpoint
app.post('/register', async (req, res) => {
  const { naam, email, wachtwoord } = req.body;
  if (!naam || !email || !wachtwoord) {
    return res.status(400).json({ error: 'Vul alle velden in.' });
  }
  const hashedPassword = await bcrypt.hash(wachtwoord, 10);
  db.run(
    'INSERT INTO users (naam, email, wachtwoord) VALUES (?, ?, ?)',
    [naam, email, hashedPassword],
    function (err) {
      if (err) {
        if (err.message.includes('UNIQUE')) {
          return res.status(400).json({ error: 'Email bestaat al.' });
        }
        return res.status(500).json({ error: 'Database fout.' });
      }
      res.json({ id: this.lastID, naam, email });
    }
  );
});

// Login endpoint
app.post('/login', (req, res) => {
  const { email, wachtwoord } = req.body;
  if (!email || !wachtwoord) {
    return res.status(400).json({ error: 'Vul alle velden in.' });
  }
  db.get('SELECT * FROM users WHERE email = ?', [email], async (err, user) => {
    if (err) return res.status(500).json({ error: 'Database fout.' });
    if (!user) return res.status(400).json({ error: 'Gebruiker niet gevonden.' });
    const match = await bcrypt.compare(wachtwoord, user.wachtwoord);
    if (!match) return res.status(400).json({ error: 'Wachtwoord onjuist.' });
    res.json({ id: user.id, naam: user.naam, email: user.email });
  });
});

app.listen(PORT, () => {
  console.log(`Server draait op http://localhost:${PORT}`);
}); 