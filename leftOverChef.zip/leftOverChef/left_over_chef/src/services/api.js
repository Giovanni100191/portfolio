import axios from "axios";

const BACKEND_URL = "http://localhost:5000";

export async function registerUser(naam, email, wachtwoord) {
  const res = await axios.post(`${BACKEND_URL}/register`, { naam, email, wachtwoord });
  return res.data;
}

export async function loginUser(email, wachtwoord) {
  const res = await axios.post(`${BACKEND_URL}/login`, { email, wachtwoord });
  return res.data;
}

// Zoek recepten op basis van ingrediënten
export async function zoekRecepten(ingrediënten) {
    // Voor elk ingrediënt: haal recepten op
    const allResults = await Promise.all(
      ingrediënten.map(async (ing) => {
        const url = `https://www.themealdb.com/api/json/v1/1/filter.php?i=${ing}`;
        const res = await axios.get(url);
        return res.data.meals || [];
      })
    );
  
    // Vind gedeelde recepten (met dezelfde id)
    const idSets = allResults.map(result =>
      new Set(result.map(meal => meal.idMeal))
    );
  
    const gemeenschappelijkeIds = [...idSets[0]].filter(id =>
      idSets.every(set => set.has(id))
    );
  
    // Zoek volledige data terug (van de eerste lijst)
    const eersteLijst = allResults[0];
    const gefilterd = eersteLijst.filter(meal => gemeenschappelijkeIds.includes(meal.idMeal));
  
    return { meals: gefilterd };
  }
  