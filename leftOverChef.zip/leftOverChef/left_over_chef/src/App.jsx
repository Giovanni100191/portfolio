import { useState, useEffect } from "react";
import { zoekRecepten } from "./services/api";
import IngredientForm from "./components/IngredientForm.jsx";
import AddRecipeForm from "./components/AddRecipeForm.jsx";
import "./App.css";
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import LoginPage from './components/LoginPage';
import RegisterPage from './components/RegisterPage';

function App() {
  const [ingredienten, setIngredienten] = useState([]);
  const [recepten, setRecepten] = useState([]);
  const [eigenRecepten, setEigenRecepten] = useState([]);
  const [favorieten, setFavorieten] = useState(() => {
    const saved = localStorage.getItem('favorieten');
    return saved ? JSON.parse(saved) : [];
  });
  const [boodschappen, setBoodschappen] = useState([]);
  const [typeFilter, setTypeFilter] = useState('');
  const [user, setUser] = useState(null);

  // Simpele tips per ingrediënt
  const ingredientTips = {
    "ei": "Bewaar eieren in de koelkast, niet in de deur.",
    "tomaat": "Tomaten niet in de koelkast bewaren voor meer smaak.",
    "kaas": "Wikkel kaas in bakpapier voor langere houdbaarheid.",
    "brood": "Brood kan goed ingevroren worden.",
    "aardappel": "Bewaar aardappels donker en koel.",
    // Voeg meer toe naar wens
  };

  // Simpele seizoensproducten (NL, lente/zomer/herfst/winter)
  const seizoensproducten = {
    lente: ["asperge", "spinazie", "radijs", "bosui"],
    zomer: ["courgette", "tomaat", "aubergine", "komkommer"],
    herfst: ["pompoen", "spruitjes", "pastinaak", "kool"],
    winter: ["boerenkool", "wortel", "prei", "knolselderij"],
  };

  // State voor porties, notities, random recept, meest gebruikte ingrediënten
  const [porties, setPorties] = useState(1);
  const [notities, setNotities] = useState({}); // {receptId: tekst}
  const [randomRecept, setRandomRecept] = useState(null);
  const [meestGebruikt, setMeestGebruikt] = useState([]);
  const [seizoen, setSeizoen] = useState('');
  const [showRandomIngrediënten, setShowRandomIngrediënten] = useState(false);

  // Voeg porties per recept toe aan favorieten
  const [portiesPerRecept, setPortiesPerRecept] = useState({}); // {receptId: aantal}

  useEffect(() => {
    localStorage.setItem('favorieten', JSON.stringify(favorieten));
  }, [favorieten]);

  // Laad user direct bij mount
  useEffect(() => {
    const stored = localStorage.getItem('loggedInUser');
    if (stored) setUser(JSON.parse(stored));
  }, []);

  const handleSearch = async (nieuweIngredienten) => {
    // Voeg toe aan bestaande ingredienten zonder duplicaten
    const gecombineerde = [...new Set([...ingredienten, ...nieuweIngredienten])].filter(i => i);
    setIngredienten(gecombineerde);

    if (gecombineerde.length === 0) {
      setRecepten([]);
      return;
    }

    const data = await zoekRecepten(gecombineerde);
    setRecepten(data.meals || []);
  };

  const verwijderIngredient = (ing) => {
    const nieuweLijst = ingredienten.filter(i => i !== ing);
    setIngredienten(nieuweLijst);

    if (nieuweLijst.length === 0) {
      setRecepten([]);
      return;
    }
    zoekRecepten(nieuweLijst).then(data => setRecepten(data.meals || []));
  };

  const handleAddRecipe = (recept) => {
    setEigenRecepten(prev => [
      ...prev,
      {
        id: 'custom-' + Date.now() + '-' + Math.random().toString(36).slice(2),
        strMeal: recept.naam,
        strMealThumb: recept.img,
        ingredienten: recept.ingredienten,
        type: recept.type,
      }
    ]);
  };

  // Filter eigen recepten op basis van zoek-ingredienten
  const eigenReceptenGefilterd = ingredienten.length === 0
    ? []
    : eigenRecepten.filter(r =>
        r.ingredienten && r.ingredienten.some(ing => ingredienten.includes(ing))
      );

  const alleRecepten = [...eigenReceptenGefilterd, ...recepten];

  // Pas toggleFavoriet aan zodat portie wordt opgeslagen
  const toggleFavoriet = (recept) => {
    setFavorieten((prev) => {
      const exists = prev.find(r => (r.idMeal || r.id) === (recept.idMeal || recept.id));
      if (exists) {
        return prev.filter(r => (r.idMeal || r.id) !== (recept.idMeal || recept.id));
      } else {
        // Voeg portie toe aan favoriet
        const id = recept.idMeal || recept.id;
        const portie = portiesPerRecept[id] || 1;
        return [...prev, { ...recept, _portie: portie }];
      }
    });
  };

  // Update portie voor een recept (ook in favorieten als het daar staat)
  const handlePortieChange = (id, value) => {
    setPortiesPerRecept(p => ({ ...p, [id]: value }));
    setFavorieten(favorieten => favorieten.map(f =>
      (f.idMeal || f.id) === id ? { ...f, _portie: value } : f
    ));
  };

  // Pas gefilterdeRecepten aan zodat als ingredienten leeg zijn maar typeFilter is gezet, je alle recepten van dat type toont
  const gefilterdeRecepten = (ingredienten.length === 0 && typeFilter)
    ? [...eigenRecepten, ...recepten].filter(r => r.type === typeFilter)
    : (typeFilter
        ? alleRecepten.filter(r => r.type === typeFilter)
        : alleRecepten);

  // Bereken meest gebruikte ingrediënten
  useEffect(() => {
    const alleIngred = [...ingredienten];
    recepten.forEach(r => {
      if (r.ingredienten) alleIngred.push(...r.ingredienten);
    });
    eigenRecepten.forEach(r => {
      if (r.ingredienten) alleIngred.push(...r.ingredienten);
    });
    const counts = {};
    alleIngred.forEach(i => { counts[i] = (counts[i] || 0) + 1; });
    const top5 = Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([naam, aantal]) => ({ naam, aantal }));
    setMeestGebruikt(top5);
  }, [ingredienten, recepten, eigenRecepten]);

  // Random recept functie
  const pickRandomRecept = () => {
    // Kies altijd uit alle recepten (eigen + API)
    const lijst = [...eigenRecepten, ...recepten];
    if (lijst.length > 0) {
      const idx = Math.floor(Math.random() * lijst.length);
      setRandomRecept(lijst[idx]);
    }
  };

  // Seizoenssuggesties ophalen
  const huidigeMaand = new Date().getMonth();
  useEffect(() => {
    if (huidigeMaand >= 2 && huidigeMaand <= 4) setSeizoen('lente');
    else if (huidigeMaand >= 5 && huidigeMaand <= 7) setSeizoen('zomer');
    else if (huidigeMaand >= 8 && huidigeMaand <= 10) setSeizoen('herfst');
    else setSeizoen('winter');
  }, [huidigeMaand]);

  return (
    <Router>
      <div className="navbar">
        <Link to="/" className="nav-link">Home</Link>
        <Link to="/login" className="nav-link">Inloggen</Link>
        <Link to="/register" className="nav-link">Registreren</Link>
        {user && (
          <button
            className="logout-btn"
            onClick={() => {
              localStorage.removeItem('loggedInUser');
              setUser(null);
            }}
            style={{marginLeft:'auto', marginRight:12, background:'#fff', color:'#2563eb', border:'none', borderRadius:8, fontWeight:700, fontSize:'1.05rem', padding:'0.4rem 1.1rem', cursor:'pointer', transition:'background 0.18s'}}
          >
            Log uit
          </button>
        )}
        <div style={{marginRight:24, color:'#fff', fontWeight:600, fontSize:'1.05rem'}}>
          {user ? `👤 ${user.naam}` : ''}
        </div>
      </div>
      <Routes>
        <Route path="/" element={
          <div className="dashboard-grid">
            {/* Linkerkant */}
            <div className="dashboard-left">
              {/* Favorieten links boven */}
              {favorieten.length > 0 && (
                <div className="favorieten-blok dashboard-box">
                  <h3>Favoriete recepten</h3>
                  <ul style={{ paddingLeft: 0 }}>
                    {favorieten.map((r) => {
                      const id = r.idMeal || r.id;
                      return (
                        <li key={id} className="recept-item favoriet-item">
                          <img src={r.strMealThumb} alt={r.strMeal} className="recept-image" />
                          <span className="recept-naam">{r.strMeal}</span>
                          <span style={{marginLeft:12}}>
                            Porties: <b>{r._portie || 1}</b>
                          </span>
                          <button
                            className="fav-remove-btn"
                            onClick={() => setFavorieten(favorieten.filter(f => (f.idMeal || f.id) !== id))}
                            title="Verwijder uit favorieten"
                            style={{marginLeft:12}}
                          >
                            Verwijder
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              )}

              {/* Willekeurig recept knop links midden */}
              <div className="dashboard-box">
                <button className="random-btn" onClick={pickRandomRecept} style={{marginBottom:16}}>Toon een willekeurig recept</button>
                {randomRecept && (
                  <div className="recepten-container random-recept-box" style={{background:'#fffbe6', cursor:'pointer'}} 
                    onClick={() => {
                      pickRandomRecept();
                      setShowRandomIngrediënten(false);
                    }}
                  >
                    <h3>Willekeurig recept</h3>
                    <div className="recept-item">
                      <img src={randomRecept.strMealThumb} alt={randomRecept.strMeal} className="recept-image" />
                      <span className="recept-naam">{randomRecept.strMeal}</span>
                    </div>
                    {showRandomIngrediënten && randomRecept.ingredienten && (
                      <div className="random-ingredienten-dropdown">
                        <h4>Ingrediënten:</h4>
                        <ul>
                          {randomRecept.ingredienten.map((ing, i) => (
                            <li key={i}>{ing}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Seizoenssuggesties links onder */}
              {seizoen && (
                <div className="seizoens-blok dashboard-box">
                  <h3>Seizoenssuggesties ({seizoen})</h3>
                  <div>
                    {seizoensproducten[seizoen].map(prod => (
                      <span key={prod} className="ingredient-tag">{prod}</span>
                    ))}
                  </div>
                </div>
              )}

              {/* Toevoegformulier links onder */}
              <div className="dashboard-box">
                <AddRecipeForm onAddRecipe={handleAddRecipe} />
              </div>
            </div>

            {/* Rechterkant */}
            <div className="dashboard-right">
              <div className="recepten-container dashboard-box">
                <IngredientForm onSearch={handleSearch} />
                <div style={{ marginBottom: '1.2rem' }}>
                  <label htmlFor="typeFilter" style={{ fontWeight: 600, marginRight: 8 }}>Filter op type:</label>
                  <select id="typeFilter" value={typeFilter} onChange={e => setTypeFilter(e.target.value)}>
                    <option value="">Alles</option>
                    <option value="ontbijt">Ontbijt</option>
                    <option value="lunch">Lunch</option>
                    <option value="diner">Diner</option>
                    <option value="vegetarisch">Vegetarisch</option>
                  </select>
                </div>
                <div className="ingredients-list" style={{marginBottom: '1.2rem'}}>
                  {ingredienten.map((ing) => (
                    <span key={ing} className="ingredient-tag">
                      {ing}
                      <button
                        className="remove-btn"
                        onClick={() => verwijderIngredient(ing)}
                        aria-label={`Verwijder ingredient ${ing}`}
                      >
                        &times;
                      </button>
                      {/* Restjes-tip */}
                      {ingredientTips[ing] && (
                        <span className="tip-badge" title="Restjes-tip">💡 {ingredientTips[ing]}</span>
                      )}
                    </span>
                  ))}
                </div>
                <h2>Gevonden recepten:</h2>
                {gefilterdeRecepten.length > 0 ? (
                  <ul style={{ paddingLeft: 0 }}>
                    {gefilterdeRecepten.map((r) => {
                      const id = r.idMeal || r.id;
                      return (
                        <li key={id} className="recept-item">
                          <img
                            src={r.strMealThumb}
                            alt={r.strMeal}
                            className="recept-image"
                          />
                          <span className="recept-naam">{r.strMeal}</span>
                          <span style={{marginLeft:12}}>
                            Porties:
                            <select value={portiesPerRecept[id] || 1} onChange={e => handlePortieChange(id, Number(e.target.value))} style={{marginLeft:4}}>
                              {[1,2,3,4,5,6].map(p => <option key={p} value={p}>{p}</option>)}
                            </select>
                          </span>
                          <button className="fav-btn" onClick={() => toggleFavoriet(r)} title="Voeg toe aan favorieten" style={{marginLeft:8}}>
                            {favorieten.find(f => (f.idMeal || f.id) === id) ? '❤️' : '🤍'}
                          </button>
                        </li>
                      );
                    })}
                  </ul>
                ) : (
                  <p className="no-results">Geen recepten gevonden</p>
                )}
              </div>
            </div>
          </div>
        } />
        <Route path="/login" element={<LoginPage setUser={setUser} />} />
        <Route path="/register" element={<RegisterPage setUser={setUser} />} />
      </Routes>
    </Router>
  );
}

export default App;
