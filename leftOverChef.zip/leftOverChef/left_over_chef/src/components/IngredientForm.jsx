import { useState } from "react";

function IngredientForm({ onSearch }) {
  const [input, setInput] = useState("");

  // Als je single ingrediënt wilt toevoegen (via knop of enter)
  const voegToe = () => {
    const nieuw = input.trim().toLowerCase();
    if (nieuw) {
      onSearch([nieuw]);  // onSearch krijgt array van 1 ingrediënt
    }
    setInput("");
  };

  // Bulk zoeken via komma gescheiden lijst (form submit)
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const ingredients = input.split(",").map(i => i.trim().toLowerCase()).filter(i => i);
    onSearch(ingredients);
    setInput("");
  };

  return (
    <form onSubmit={handleSubmit}>
      <div style={{ display: "flex", gap: "8px", marginBottom: "1rem" }}>
        <input
          type="text"
          placeholder="Voer ingrediënt in (1 voor 1)"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              if (input.includes(",")) {
                handleSubmit(e);
              } else {
                voegToe();
              }
            }
          }}
          style={{ flex: 1, padding: "0.5rem 0.75rem", fontSize: "1rem" }}
        />
        <button
          type="button"
          onClick={voegToe}
          style={{
            backgroundColor: "#3498db",
            color: "white",
            border: "none",
            borderRadius: "6px",
            padding: "0 1rem",
            cursor: "pointer",
            fontWeight: "600",
          }}
        >
          Toevoegen
        </button>
      </div>
    </form>
  );
}

export default IngredientForm;
