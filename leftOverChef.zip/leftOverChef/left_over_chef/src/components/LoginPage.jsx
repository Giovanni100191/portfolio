import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { loginUser } from '../services/api';

function LoginPage({ setUser }) {
  const [email, setEmail] = useState('');
  const [wachtwoord, setWachtwoord] = useState('');
  const [melding, setMelding] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const user = await loginUser(email, wachtwoord);
      setMelding('U bent succesvol ingelogd');
      setTimeout(() => {
        setMelding('');
        localStorage.setItem('loggedInUser', JSON.stringify(user));
        setUser(user);
        navigate('/');
      }, 1200);
    } catch (err) {
      setMelding(err.response?.data?.error || 'Inloggen mislukt');
    }
  };

  return (
    <div style={{maxWidth:400, margin:'60px auto', background:'#fff', borderRadius:12, boxShadow:'0 2px 16px #0001', padding:32}}>
      <h2 style={{textAlign:'center'}}>Inloggen</h2>
      {melding && <div style={{background:'#22c55e', color:'#fff', borderRadius:8, padding:'10px 0', marginBottom:16, textAlign:'center', fontWeight:600}}>{melding}</div>}
      <form onSubmit={handleSubmit} style={{display:'flex', flexDirection:'column', gap:16}}>
        <input type="email" placeholder="E-mail" value={email} onChange={e=>setEmail(e.target.value)} required style={{padding:10, borderRadius:6, border:'1.5px solid #e5e7eb'}} />
        <input type="password" placeholder="Wachtwoord" value={wachtwoord} onChange={e=>setWachtwoord(e.target.value)} required style={{padding:10, borderRadius:6, border:'1.5px solid #e5e7eb'}} />
        <button type="submit" style={{background:'#2563eb', color:'#fff', border:'none', borderRadius:8, padding:12, fontWeight:700, fontSize:'1.1rem', cursor:'pointer'}}>Inloggen</button>
      </form>
      <div style={{marginTop:18, textAlign:'center'}}>
        <a href="/register" style={{color:'#2563eb', textDecoration:'underline'}}>Nog geen account? Registreren</a>
      </div>
    </div>
  );
}

export default LoginPage; 