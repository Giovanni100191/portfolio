import { useState, useRef } from "react";

function AddRecipeForm({ onAddRecipe }) {
  const [naam, setNaam] = useState("");
  const [ingredienten, setIngredienten] = useState("");
  const [imgData, setImgData] = useState("");
  const [dragActive, setDragActive] = useState(false);
  const [type, setType] = useState("");
  const fileInputRef = useRef();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!naam.trim() || !imgData || !ingredienten.trim()) return;
    const ingredientenArray = ingredienten
      .split(",")
      .map(i => i.trim().toLowerCase())
      .filter(i => i);
    onAddRecipe({ naam: naam.trim(), img: imgData, ingredienten: ingredientenArray, type });
    setNaam("");
    setImgData("");
    setIngredienten("");
    setType("");
  };

  const handleFile = (file) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      setImgData(e.target.result);
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: "2rem" }}>
      <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
        <input
          type="text"
          placeholder="Naam van het gerecht"
          value={naam}
          onChange={e => setNaam(e.target.value)}
          style={{ padding: "0.5rem 0.75rem", fontSize: "1rem" }}
        />
        <input
          type="text"
          placeholder="Ingrediënten (komma gescheiden)"
          value={ingredienten}
          onChange={e => setIngredienten(e.target.value)}
          style={{ padding: "0.5rem 0.75rem", fontSize: "1rem" }}
        />
        <select value={type} onChange={e => setType(e.target.value)} style={{ padding: "0.5rem 0.75rem", fontSize: "1rem", borderRadius: 8, border: '1.5px solid #e5e7eb' }}>
          <option value="">Kies type gerecht</option>
          <option value="ontbijt">Ontbijt</option>
          <option value="lunch">Lunch</option>
          <option value="diner">Diner</option>
          <option value="vegetarisch">Vegetarisch</option>
        </select>
        <div
          className={`add-recipe-dropbox${dragActive ? " drag-active" : ""}`}
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current.click()}
        >
          {imgData ? (
            <img src={imgData} alt="preview" />
          ) : (
            <span>
              Sleep een afbeelding hierheen of klik om te kiezen
            </span>
          )}
          <input
            type="file"
            accept="image/*"
            ref={fileInputRef}
            style={{ display: "none" }}
            onChange={handleChange}
          />
        </div>
        <button
          type="submit"
          className="add-btn"
        >
          Voeg toe
        </button>
      </div>
    </form>
  );
}

export default AddRecipeForm; 