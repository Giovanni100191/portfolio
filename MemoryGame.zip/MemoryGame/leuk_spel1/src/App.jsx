import { useState, useEffect } from 'react'
import './App.css'

const cardImages = [
  { src: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=facearea&w=200&q=80', matched: false },
  { src: 'https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=facearea&w=200&q=80', matched: false },
  { src: 'https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=facearea&w=200&q=80', matched: false },
  { src: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=facearea&w=200&q=80', matched: false },
  { src: 'https://images.unsplash.com/photo-1518717758536-85ae29035b6d?auto=format&fit=facearea&w=200&q=80', matched: false },
  { src: 'https://images.unsplash.com/photo-1519985176271-adb1088fa94c?auto=format&fit=facearea&w=200&q=80', matched: false },
  { src: 'https://images.unsplash.com/photo-1465101178521-c1a9136a3b99?auto=format&fit=facearea&w=200&q=80', matched: false },
  { src: 'https://images.unsplash.com/photo-1502082553048-f009c37129b9?auto=format&fit=facearea&w=200&q=80', matched: false },
  { src: 'https://images.unsplash.com/photo-1468373717403-5832a7bfa9d0?auto=format&fit=facearea&w=200&q=80', matched: false },
  { src: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=facearea&w=200&q=80', matched: false },
  { src: 'https://images.unsplash.com/photo-1463453091185-61582044d556?auto=format&fit=facearea&w=200&q=80', matched: false },
  { src: 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=facearea&w=200&q=80', matched: false },
  { src: 'https://images.unsplash.com/photo-1465101053361-763ab02bced9?auto=format&fit=facearea&w=200&q=80', matched: false },
  { src: 'https://images.unsplash.com/photo-1465101178521-c1a9136a3b99?auto=format&fit=facearea&w=200&q=80', matched: false },
  { src: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=facearea&w=200&q=80', matched: false },
  { src: 'https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=facearea&w=200&q=80', matched: false },
  { src: 'https://images.unsplash.com/photo-1465101178521-c1a9136a3b99?auto=format&fit=facearea&w=200&q=80', matched: false },
  { src: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=facearea&w=200&q=80', matched: false },
  { src: 'https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=facearea&w=200&q=80', matched: false },
  { src: 'https://images.unsplash.com/photo-1465101178521-c1a9136a3b99?auto=format&fit=facearea&w=200&q=80', matched: false },
];

const MAX_LEVEL = 10;

function shuffleCards(level) {
  const pairs = cardImages.slice(0, level + 2); // level 1 = 3 paren, level 2 = 4, etc.
  const shuffled = [...pairs, ...pairs]
    .map(card => ({ ...card, id: Math.random() }))
    .sort(() => Math.random() - 0.5);
  return shuffled;
}

function App() {
  const [level, setLevel] = useState(1); // start op level 1 (3 paren)
  const [cards, setCards] = useState([]);
  const [turns, setTurns] = useState(0);
  const [choiceOne, setChoiceOne] = useState(null);
  const [choiceTwo, setChoiceTwo] = useState(null);
  const [disabled, setDisabled] = useState(false);
  const [gameWon, setGameWon] = useState(false);
  const [gameCompleted, setGameCompleted] = useState(false);

  useEffect(() => {
    setCards(shuffleCards(level));
    setTurns(0);
    setChoiceOne(null);
    setChoiceTwo(null);
    setGameWon(false);
    setGameCompleted(false);
  }, [level]);

  useEffect(() => {
    if (choiceOne && choiceTwo) {
      setDisabled(true);
      if (choiceOne.src === choiceTwo.src) {
        setCards(prevCards => {
          return prevCards.map(card => {
            if (card.src === choiceOne.src) {
              return { ...card, matched: true };
            } else {
              return card;
            }
          });
        });
        resetTurn();
      } else {
        setTimeout(() => resetTurn(), 1000);
      }
    }
  }, [choiceOne, choiceTwo]);

  useEffect(() => {
    if (cards.length > 0 && cards.every(card => card.matched)) {
      setGameWon(true);
      if (level === MAX_LEVEL) {
        setGameCompleted(true);
      }
    }
  }, [cards, level]);

  const handleChoice = (card) => {
    if (!disabled) {
      if (card === choiceOne) return;
      choiceOne ? setChoiceTwo(card) : setChoiceOne(card);
    }
  };

  const resetTurn = () => {
    setChoiceOne(null);
    setChoiceTwo(null);
    setTurns(t => t + 1);
    setDisabled(false);
  };

  const handleNewGame = () => {
    setLevel(1);
    setCards(shuffleCards(1));
    setTurns(0);
    setChoiceOne(null);
    setChoiceTwo(null);
    setGameWon(false);
    setGameCompleted(false);
  };

  const handleNextLevel = () => {
    if (level < MAX_LEVEL) {
      setLevel(lvl => lvl + 1);
    } else {
      // max level gehaald
      setLevel(1);
    }
  };

  return (
    <div className="memory-container">
      <h1>Memory Game</h1>
      <p>Level: {level} ({level + 2} paren)</p>
      <button className="new-game-btn" onClick={handleNewGame}>Nieuw spel</button>
      <p>Beurten: {turns}</p>
      <div className="card-grid">
        {cards.map((card, idx) => {
          const flipped = card === choiceOne || card === choiceTwo || card.matched;
          return (
            <div
              className={`memory-card${flipped ? ' flipped' : ''}`}
              key={idx + '-' + card.src}
              onClick={() => handleChoice(card)}
            >
              <div className="card-inner">
                <div className="card-front"></div>
                <img className="card-back" src={card.src} alt="memory card" />
              </div>
            </div>
          );
        })}
      </div>
      {gameWon && !gameCompleted && (
        <div style={{ marginTop: '2rem' }}>
          <h2>Level gehaald!</h2>
          <button className="new-game-btn" onClick={handleNextLevel}>
            Volgend level
          </button>
        </div>
      )}
      {gameCompleted && (
        <div style={{ marginTop: '2rem' }}>
          <h2>Goed gedaan, je hebt het spel uitgespeeld!</h2>
          <button className="new-game-btn" onClick={handleNewGame}>
            Opnieuw beginnen
          </button>
        </div>
      )}
    </div>
  );
}

export default App
