<?php
require 'config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (empty($email) || empty($password)) {
        $_SESSION['error'] = "Vul zowel een e-mailadres als een wachtwoord in.";
        header("Location: login.php");
        exit();
    }

    $query = "SELECT * FROM users WHERE email = :email";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['ID'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['profielfoto'] = $user['profielfoto'];
            $_SESSION['login_success'] = true;

            header("Location: index.php?login=success");
            exit();
        } else {
            $_SESSION['error'] = "Het ingevoerde wachtwoord is onjuist.";
            header("Location: login.php");
            exit();
        }
    } else {
        $_SESSION['error'] = "Er bestaat geen account met dit e-mailadres.";
        header("Location: login.php");
        exit();
    }
} else {
    header("Location: login.php");
    exit();
}
?>
