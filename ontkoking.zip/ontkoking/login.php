<?php
session_start();
if (isset($_SESSION['error'])) {
    echo "<div class='alert alert-danger' id='errorMessage'>" . $_SESSION['error'] . "</div>";
    unset($_SESSION['error']); // Verwijder de foutmelding na het tonen
}

include "views/login_view.php";
?>

<!-- Voeg dit script toe om de melding te laten verdwijnen -->
<script>
    // Verberg het foutbericht na 3 seconden
    setTimeout(function() {
        var errorMessage = document.getElementById('errorMessage');
        if (errorMessage) {
            errorMessage.style.display = 'none';
        }
    }, 3000); // 3000 milliseconden = 3 seconden
</script>
