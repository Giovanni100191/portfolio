<?php
include "views/add_view.php";
session_start();

if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = 'Je moet ingelogd zijn om deze pagina te bezoeken.';
    header("Location: login.php");
    exit();
}
?>
