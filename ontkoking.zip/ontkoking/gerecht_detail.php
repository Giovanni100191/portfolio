<?php
require 'config.php';

$gerecht_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($gerecht_id > 0) {
    try {
        $stmt = $conn->prepare("SELECT `naam`, `hoeveelheid`, `eenheid`, `beschrijving` FROM `ingrediënten_info`, gerecht_ingredient_koppel WHERE gerecht_ingredient_koppel.ingrediënten_ID = ingrediënten_info.`ingrediënten_ID` AND gerecht_ingredient_koppel.gerechten_ID = :id");
        $stmt->bindValue(':id', $gerecht_id, PDO::PARAM_INT);
        $stmt->execute();

        $ingredienten = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stmt = $conn->prepare("SELECT * FROM gerechten_info WHERE gerechten_ID = :id");
        $stmt->bindValue(':id', $gerecht_id, PDO::PARAM_INT);
        $stmt->execute();

        $gerecht = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($gerecht) {
            $user_id = $gerecht['user_ID'];
            $stmt_user = $conn->prepare("SELECT username FROM users WHERE id = :user_id");
            $stmt_user->bindValue(':user_id', $user_id, PDO::PARAM_INT);
            $stmt_user->execute();

            $user = $stmt_user->fetch(PDO::FETCH_ASSOC);

            include 'views/gerecht_detail_view.php';
        } else {
            echo "<p>Dish not found.</p>";
        }
    } catch (PDOException $e) {
        echo "<p>Fout bij het ophalen van de gegevens: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p>Ongeldig gerecht ID.</p>";
}

function addParagraphs($bereiding)
{
    return str_replace("##", "</p><p>", $bereiding);
}
?>
