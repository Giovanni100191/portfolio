<?php
session_start();

include 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $user_id = $_SESSION['user_id'];

    if (isset($_FILES['profielfoto']) && $_FILES['profielfoto']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['profielfoto']['tmp_name'];
        $fileName = $_FILES['profielfoto']['name'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));

        $allowedfileExtensions = array('jpg', 'jpeg', 'png');
        if (in_array($fileExtension, $allowedfileExtensions)) {
            $uploadFileDir = 'uploads/';
            $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
            $dest_path = $uploadFileDir . $newFileName;

            if (move_uploaded_file($fileTmpPath, $dest_path)) {
                $profielfoto = $newFileName;

                $sql = "UPDATE users SET username = ?, profielfoto = ? WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->execute([$username, $profielfoto, $user_id]);

                $_SESSION['username'] = $username;
                $_SESSION['profielfoto'] = $profielfoto;

                header('Location: index.php');
                exit();
            } else {
                $_SESSION['error'] = 'Er ging iets mis met het uploaden van het bestand.';
                header('Location: profile.php');
                exit();
            }
        } else {
            $_SESSION['error'] = 'Alleen .jpg, .jpeg en .png bestanden zijn toegestaan.';
            header('Location: profile.php');
            exit();
        }
    } else {
        $sql = "UPDATE users SET username = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$username, $user_id]);

        $_SESSION['username'] = $username;

        header('Location: profile.php');
        exit();
    }
}
