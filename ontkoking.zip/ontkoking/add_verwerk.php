<?php
session_start();

require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $naam = $_POST['naam'];
    $tijdsduur = $_POST['tijdsduur'];
    $moeilijkheidsgraad = $_POST['moeilijkheidsgraad'];
    $beschrijving = $_POST['beschrijving'];
    $user_id = $_SESSION['user_id'];

    $beschrijving = addParagraphs($beschrijving);

    $imageName = null;
    if (isset($_FILES['afbeelding']) && $_FILES['afbeelding']['error'] === 0) {
        $uploadDir = 'image/';
        $fileTmpPath = $_FILES['afbeelding']['tmp_name'];
        $fileName = basename($_FILES['afbeelding']['name']);

        $uniqueFileName = uniqid() . '_' . $fileName;
        $destinationPath = $uploadDir . $uniqueFileName;

        if (move_uploaded_file($fileTmpPath, $destinationPath)) {
            $imageName = $uniqueFileName;
        } else {
            $_SESSION['error'] = 'Failed to upload image';
            header('Location: add.php');
            exit();
        }
    }

    $ingredients = isset($_POST['ingredients']) ? $_POST['ingredients'] : [];
    $quantities = isset($_POST['quantities']) ? $_POST['quantities'] : [];
    $units = isset($_POST['units']) ? $_POST['units'] : [];

    try {
        $conn->beginTransaction();

        $query = "INSERT INTO gerechten_info (naam, tijdsduur, moeilijkheidsgraad, beschrijving, afbeelding, user_ID) 
                  VALUES (:naam, :tijdsduur, :moeilijkheidsgraad, :beschrijving, :afbeelding, :user_id)";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':naam', $naam);
        $stmt->bindParam(':tijdsduur', $tijdsduur);
        $stmt->bindParam(':moeilijkheidsgraad', $moeilijkheidsgraad);
        $stmt->bindParam(':beschrijving', $beschrijving);
        $stmt->bindParam(':afbeelding', $imageName);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();

        $last_ID = $conn->lastInsertId();

        for ($i = 0; $i < count($ingredients); $i++) {
            $ingredient = $ingredients[$i];
            $hoeveelheid = isset($quantities[$i]) ? $quantities[$i] : null;
            $eenheid = isset($units[$i]) ? $units[$i] : null;

            $checkQuery = "SELECT ingrediënten_ID FROM ingrediënten_info WHERE naam = :ingredient";
            $checkStmt = $conn->prepare($checkQuery);
            $checkStmt->bindParam(':ingredient', $ingredient);
            $checkStmt->execute();
            $existingIngredient = $checkStmt->fetch(PDO::FETCH_ASSOC);

            if ($existingIngredient) {
                $ingredient_id = $existingIngredient['ingrediënten_ID'];
            } else {
                $insertQuery = "INSERT INTO ingrediënten_info (naam) VALUES (:ingredient)";
                $insertStmt = $conn->prepare($insertQuery);
                $insertStmt->bindParam(':ingredient', $ingredient);
                $insertStmt->execute();

                $ingredient_id = $conn->lastInsertId();
            }

            $relationQuery = "INSERT INTO gerecht_ingredient_koppel (gerechten_ID, ingrediënten_ID, hoeveelheid, eenheid) 
                              VALUES (:gerecht_ID, :ingredient_ID, :hoeveelheid, :eenheid)";
            $relationStmt = $conn->prepare($relationQuery);
            $relationStmt->bindParam(':gerecht_ID', $last_ID);
            $relationStmt->bindParam(':ingredient_ID', $ingredient_id);
            $relationStmt->bindParam(':hoeveelheid', $hoeveelheid);
            $relationStmt->bindParam(':eenheid', $eenheid);
            $relationStmt->execute();
        }

        $conn->commit();

        $_SESSION['success'] = 'Gerecht met ingrediënten succesvol toegevoegd!';
        header('Location: index.php');
        exit();
    } catch (PDOException $e) {
        $conn->rollBack();
        echo 'Databasefout: ' . $e->getMessage();
        exit();
    }
}

function addParagraphs($bereiding)
{
    $bereiding = trim($bereiding);

    $bereiding = preg_replace("/(\r\n|\n){2,}/", "##", $bereiding);

    $paragraphs = explode("##", $bereiding);

    $numberedParagraphs = [];
    foreach ($paragraphs as $index => $paragraph) {
        $number = $index + 1;
        $numberedParagraphs[] = $number . ". " . trim($paragraph);
    }

    return implode("##", $numberedParagraphs);
}

function formatParagraphs($bereiding)
{
    return '<p>' . str_replace("##", "</p><p>", $bereiding) . '</p>';
}
?>
