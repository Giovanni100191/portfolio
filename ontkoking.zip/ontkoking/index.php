<?php
require 'config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['login_success'])) {
    echo "<div class='alert alert-success' id='successMessage'>Succesfully logged in!</div>";
    unset($_SESSION['login_success']);
}

try {
    $query = "SELECT gerechten_ID, naam, afbeelding, tijdsduur, moeilijkheidsgraad, username, user_ID FROM gerechten_info JOIN users ON users.ID = gerechten_info.user_ID WHERE 1=1";

    // Zoekfilters
    $zoekterm = isset($_GET['search']) && !empty($_GET['search']) ? "%" . htmlspecialchars($_GET['search']) . "%" : null;
    $tijdsduur = isset($_GET['tijdsduur']) && !empty($_GET['tijdsduur']) ? $_GET['tijdsduur'] : null;
    $moeilijkheidsgraad = isset($_GET['moeilijkheidsgraad']) && !empty($_GET['moeilijkheidsgraad']) ? $_GET['moeilijkheidsgraad'] : null;
    $user_id = isset($_GET['user_id']) ? $_GET['user_id'] : null;

    $parameters = [];

    if ($zoekterm) {
        $query .= " AND (naam LIKE :zoekterm_naam OR username LIKE :zoekterm_username)";
        $parameters[':zoekterm_naam'] = $zoekterm;
        $parameters[':zoekterm_username'] = $zoekterm;
    }

    if ($tijdsduur) {
        if ($tijdsduur === '0-30') {
            $query .= " AND tijdsduur <= 30";
        } elseif ($tijdsduur === '30-60') {
            $query .= " AND tijdsduur > 30 AND tijdsduur <= 60";
        } elseif ($tijdsduur === '60+') {
            $query .= " AND tijdsduur > 60";
        }
    }

    if ($moeilijkheidsgraad) {
        $query .= " AND moeilijkheidsgraad = :moeilijkheidsgraad";
        $parameters[':moeilijkheidsgraad'] = $moeilijkheidsgraad;
    }

    if ($user_id) {
        $query .= " AND user_ID = :user_id";
        $parameters[':user_id'] = $user_id;
    }

    $stmt = $conn->prepare($query);

    foreach ($parameters as $key => $value) {
        $stmt->bindValue($key, $value);
    }

    $stmt->execute();
    $resultaten = $stmt->fetchAll();

    include 'views/index_view.php';

} catch (PDOException $e) {
    echo "<p>Fout met de databasequery:</p>";
    echo "<p>Foutmelding: " . $e->getMessage() . "</p>";
}

?>

<script>
    setTimeout(function () {
        var successMessage = document.getElementById('successMessage');
        if (successMessage) {
            successMessage.style.display = 'none';
        }
    }, 3000);
</script>
