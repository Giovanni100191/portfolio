<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $profielfoto = $_FILES['profielfoto'];

    if (empty($username) || empty($email) || empty($password)) {
        header("Location: register.php?error=emptyfields");
        exit();
    }

    $query = "SELECT * FROM users WHERE email = :email";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        header("Location: register.php?error=emailtaken");
        exit();
    }

    if ($profielfoto['error'] === 0) {
        $fotoNaam = $profielfoto['name'];
        $fotoTmpNaam = $profielfoto['tmp_name'];
        $fotoSize = $profielfoto['size'];
        $fotoError = $profielfoto['error'];
        $fotoType = $profielfoto['type'];

        $fotoExt = strtolower(pathinfo($fotoNaam, PATHINFO_EXTENSION));

        $toegestaneExtensies = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($fotoExt, $toegestaneExtensies)) {
            if ($fotoSize < 5000000) {
                $nieuweFotoNaam = uniqid('', true) . "." . $fotoExt;
                $fotoBestemming = 'uploads/' . $nieuweFotoNaam;

                move_uploaded_file($fotoTmpNaam, $fotoBestemming);
            } else {
                header("Location: register.php?error=filetoobig");
                exit();
            }
        } else {
            header("Location: register.php?error=invalidfiletype");
            exit();
        }
    } else {
        $nieuweFotoNaam = 'default.png';
    }

    // Wachtwoord hashen
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Gebruiker invoegen in de database
    $query = "INSERT INTO users (username, email, password, profielfoto) VALUES (:username, :email, :password, :profielfoto)";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password', $hashedPassword);
    $stmt->bindParam(':profielfoto', $nieuweFotoNaam);

    if ($stmt->execute()) {
        header("Location: login.php?success=registered");
        exit();
    } else {
        header("Location: register.php?error=sqlerror");
        exit();
    }
} else {
    header("Location: register.php");
    exit();
}
?>
