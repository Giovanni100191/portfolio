<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $phone = isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : 'Geen telefoonnummer opgegeven';
    $business = isset($_POST['business']) ? htmlspecialchars($_POST['business']) : 'Geen bedrijfsnaam opgegeven';
    $message = htmlspecialchars($_POST['message']);

    $to = 'arsengazarjan@caiway.net';
    $subject = 'Nieuw bericht van contactformulier';

    $email_content = "Je hebt een nieuw bericht ontvangen van je contactformulier:\n\n";
    $email_content .= "Naam: $name\n";
    $email_content .= "E-mail: $email\n";
    $email_content .= "Telefoonnummer: $phone\n";
    $email_content .= "Bedrijfsnaam: $business\n";
    $email_content .= "Bericht:\n$message\n";

    $headers = "From: $email";

    if (mail($to, $subject, $email_content, $headers)) {

        $user_subject = "Bevestiging van je bericht";
        $user_message = "Beste $name,\n\n";
        $user_message .= "Bedankt voor je bericht! We hebben je bericht goed ontvangen en zullen zo snel mogelijk reageren.\n\n";
        $user_message .= "Vriendelijke groeten,\n";
        $user_message .= "Het team van T7-shield";

        $user_headers = "From: no-reply@jouwwebsite.nl";

        mail($email, $user_subject, $user_message, $user_headers);

        $_SESSION['success_message'] = "Je bericht is succesvol verzonden. We nemen zo snel mogelijk contact met je op.";
        header("Location: index.php");
        exit();
    } else {
        $_SESSION['error_message'] = "Er is een fout opgetreden bij het versturen van je bericht. Probeer het later opnieuw.";
        header("Location: index.php");
    }
}
?>
