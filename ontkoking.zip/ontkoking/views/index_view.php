<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recepten Website</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
<nav id="header" class="navbar navbar-expand-lg">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">
            <img src="image/logo.PNG" alt="Logo" style="width: 150px;">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span id="burger" class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul id="knoppen" class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="add.php">Toevoegen</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact</a>
                </li>
            </ul>

            <form class="d-flex flex-wrap search-container" method="GET" action="index.php">
                <select id="select1" class="form-select" name="tijdsduur">
                    <option value="">Bereidingstijd</option>
                    <option value="0-30" <?= isset($_GET['tijdsduur']) && $_GET['tijdsduur'] == '0-30' ? 'selected' : '' ?>>0 - 30 minuten</option>
                    <option value="30-60" <?= isset($_GET['tijdsduur']) && $_GET['tijdsduur'] == '30-60' ? 'selected' : '' ?>>30 - 60 minuten</option>
                    <option value="60+" <?= isset($_GET['tijdsduur']) && $_GET['tijdsduur'] == '60+' ? 'selected' : '' ?>>Meer dan 60 minuten</option>
                </select>

                <select id="select2" class="form-select" name="moeilijkheidsgraad">
                    <option value="">Moeilijkheidsgraad</option>
                    <?php for ($i = 1; $i <= 10; $i++): ?>
                        <option value="<?= $i ?>" <?= isset($_GET['moeilijkheidsgraad']) && $_GET['moeilijkheidsgraad'] == $i ? 'selected' : '' ?>><?= $i ?></option>
                    <?php endfor; ?>
                </select>

                <input id="search" class="form-control" type="search" name="search" placeholder="Zoek een gerecht..." aria-label="Zoeken" value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">

                <button id="zoek" class="btn btn-dark" type="submit">Zoeken</button>

            </form>

            <ul class="navbar-nav ms-auto" id="login">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li id="log" class="nav-item">
                        <a id="profielBox" class="btn btn-outline-light d-flex align-items-center" href="profile.php">
                            <?php if (isset($_SESSION['profielfoto']) && $_SESSION['profielfoto'] != 'default.png'): ?>
                                <img src="uploads/<?= htmlspecialchars($_SESSION['profielfoto']) ?>" alt="Profielfoto" class="rounded-circle">
                            <?php else: ?>
                                <div id="profiel">👤</div>
                            <?php endif; ?>
                            <?= htmlspecialchars($_SESSION['username']) ?>
                        </a>
                        <a class="btn btn-outline-light" href="logout.php">Uitloggen</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="btn btn-outline-light" href="login.php">Inloggen</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<?php if (isset($_SESSION['login_success'])): ?>
    <div class='alert alert-success' id='loginSuccessMessage'>Succesvol ingelogd!</div>
    <?php unset($_SESSION['login_success']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['success']) && $_SESSION['success']): ?>
    <div id="addSuccessMessage" class="alert alert-success success-message" role="alert">
        Gerecht met ingrediënten succesvol toegevoegd!
    </div>
    <?php unset($_SESSION['success']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['success_message'])): ?>
    <div id="successMessage" class="alert alert-success">
        <?= htmlspecialchars($_SESSION['success_message']) ?>
    </div>
    <?php unset($_SESSION['success_message']);?>
<?php endif; ?>

<?php if (isset($_SESSION['error_message'])): ?>
    <div class="alert alert-danger">
        <?= htmlspecialchars($_SESSION['error_message']) ?>
    </div>
    <?php unset($_SESSION['error_message']); ?>
<?php endif; ?>

<div class="container mt-5">
    <?php if (isset($_GET['user_id'])): ?>
        <a href="index.php" class="btn btn-secondary mb-3">Toon alle gerechten</a>
    <?php endif; ?>

    <?php if (isset($_GET['search']) && !empty($_GET['search'])): ?>
        <a href="index.php" class="btn btn-secondary mb-3">Toon alle gerechten</a>
    <?php endif; ?>

    <div class="row">
        <?php if (empty($resultaten)) : ?>
            <div class="col-12 d-flex justify-content-center align-items-center" style="height: 50vh;">
                <div class="text-center">
                    <h3>Geen resultaten gevonden</h3>
                    <p>Probeer een andere zoekopdracht of pas de filters aan.</p>
                </div>
            </div>
        <?php else : ?>
            <?php foreach ($resultaten as $gerecht) : ?>
                <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                    <div class="card h-100">
                        <img src="image/<?= $gerecht['afbeelding'] ?>" class="card-img-top card-img-custom" alt="<?= $gerecht['naam'] ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($gerecht['naam']) ?></h5>
                            <p class="card-text">Duur: <?= htmlspecialchars($gerecht['tijdsduur']) ?> min.</p>
                            <p class="card-text">Moeilijkheidsgraad: <?= htmlspecialchars($gerecht['moeilijkheidsgraad']) ?>/10</p>
                            <a href="index.php?user_id=<?= $gerecht['user_ID'] ?>" style="color: black;">
                                <?= htmlspecialchars($gerecht['username']) ?>
                            </a>
                        </div>
                        <div class="card-footer text-center">
                            <a href="gerecht_detail.php?id=<?= $gerecht['gerechten_ID'] ?>" class="btn btn-dark">Meer</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.querySelector('form').addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            this.submit();
        }
    });

    function hideMessage() {
        const messageIds = ['loginSuccessMessage', 'addSuccessMessage', 'successMessage'];
        messageIds.forEach(id => {
            const messageElement = document.getElementById(id);
            if (messageElement) {
                setTimeout(() => {
                    messageElement.style.display = 'none';
                }, 2000);
            }
        });
    }
    hideMessage();
</script>

</body>
</html>
