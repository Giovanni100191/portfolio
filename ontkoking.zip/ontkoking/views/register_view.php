<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registreren</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <style>
        .file-upload {
            border: 2px dashed #007bff;
            border-radius: 5px;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            margin-bottom: 15px;
        }
        .file-upload.hover {
            background-color: #f0f8ff;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <h2 class="text-center">Maak een account aan</h2>

            <form method="POST" action="register_verwerk.php" enctype="multipart/form-data">
                <div class="form-group mb-3">
                    <label for="username">Gebruikersnaam</label>
                    <input type="text" class="form-control" id="username" name="username" placeholder="Voer je gebruikersnaam in" required>
                </div>
                <div class="form-group mb-3">
                    <label for="email">E-mail</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Voer je e-mail in" required>
                </div>
                <div class="form-group mb-3">
                    <label for="password">Wachtwoord</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Voer een wachtwoord in" required>
                </div>
                <div class="form-group mb-3">
                    <label for="profielfoto">Profielfoto</label>
                    <div id="file-upload" class="file-upload">
                        <p>Sleep een afbeelding hierheen of klik om te uploaden</p>
                        <input type="file" class="d-none" id="profielfoto" name="profielfoto" accept="image/*">
                    </div>
                </div>

                <button type="submit" class="btn btn-primary w-100">Registreren</button>
            </form>

            <div class="text-center mt-3">
                <p>Al een account? <a href="login.php">Log hier in!</a></p>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const fileUpload = document.getElementById('file-upload');
    const fileInput = document.getElementById('profielfoto');

    fileUpload.addEventListener('click', () => {
        fileInput.click();
    });

    fileUpload.addEventListener('dragover', (e) => {
        e.preventDefault();
        fileUpload.classList.add('hover');
    });

    fileUpload.addEventListener('dragleave', () => {
        fileUpload.classList.remove('hover');
    });

    fileUpload.addEventListener('drop', (e) => {
        e.preventDefault();
        fileUpload.classList.remove('hover');
        const files = e.dataTransfer.files;

        if (files.length > 1) {
            alert("Je kunt maar één afbeelding tegelijk uploaden.");
            return;
        }

        if (files.length === 1) {
            const file = files[0];
            if (file.type.startsWith('image/')) {
                fileInput.files = files;
                fileUpload.querySelector('p').textContent = file.name;
            } else {
                alert("Gelieve een geldig afbeeldingsbestand te droppen.");
            }
        }
    });
</script>
</body>
</html>
