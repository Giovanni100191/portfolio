<?php
session_start();
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerecht Details</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <style>
        .gerecht-image {
            width: 100%;
            height: 700px;
            object-fit: cover;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .content-right {
            padding-left: 50px;
        }

        .scrollable-div {
            max-height: 300px;
            overflow-y: auto;
            overflow-wrap: normal;
            padding: 10px;
            color: black;
            border: 1px solid #000000;
            border-radius: 5px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<nav id="header" class="navbar navbar-expand-lg">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">
            <img src="image/logo.PNG" alt="Logo" style="width: 150px;">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span id="burger" class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul id="knoppen" class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="add.php">Toevoegen</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact</a>
                </li>
            </ul>

            <form class="d-flex flex-wrap search-container" method="GET" action="index.php">
                <select id="select1" class="form-select" name="tijdsduur">
                    <option value="">Bereidingstijd</option>
                    <option value="0-30" <?= isset($_GET['tijdsduur']) && $_GET['tijdsduur'] == '0-30' ? 'selected' : '' ?>>0 - 30 minuten</option>
                    <option value="30-60" <?= isset($_GET['tijdsduur']) && $_GET['tijdsduur'] == '30-60' ? 'selected' : '' ?>>30 - 60 minuten</option>
                    <option value="60+" <?= isset($_GET['tijdsduur']) && $_GET['tijdsduur'] == '60+' ? 'selected' : '' ?>>Meer dan 60 minuten</option>
                </select>

                <select id="select2" class="form-select" name="moeilijkheidsgraad">
                    <option value="">Moeilijkheidsgraad</option>
                    <?php for ($i = 1; $i <= 10; $i++): ?>
                        <option value="<?= $i ?>" <?= isset($_GET['moeilijkheidsgraad']) && $_GET['moeilijkheidsgraad'] == $i ? 'selected' : '' ?>><?= $i ?></option>
                    <?php endfor; ?>
                </select>

                <input id="search" class="form-control" type="search" name="search" placeholder="Zoek een gerecht..." aria-label="Zoeken" value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">

                <button id="zoek" class="btn btn-yellow" type="submit">Zoeken</button>
            </form>

            <ul class="navbar-nav ms-auto" id="login">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li id="log" class="nav-item">
                        <a id="profielBox" class="btn btn-outline-light d-flex align-items-center" href="profile.php">
                            <?php if (isset($_SESSION['profielfoto']) && $_SESSION['profielfoto'] != 'default.png'): ?>
                                <img src="uploads/<?= htmlspecialchars($_SESSION['profielfoto']) ?>" alt="Profielfoto" class="rounded-circle">
                            <?php else: ?>
                                <div id="profiel">👤</div>
                            <?php endif; ?>
                            <?= htmlspecialchars($_SESSION['username']) ?>
                        </a>
                        <a class="btn btn-outline-light" href="logout.php">Uitloggen</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="btn btn-outline-light" href="login.php">Inloggen</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-6">
            Gemaakt door - <a href="index.php?user_id=<?= $gerecht['user_ID'] ?>" style="color: black;"><strong><?= htmlspecialchars($user['username'] ?? 'Onbekende Gebruiker') ?></strong></a>
            <img src="image/<?= htmlspecialchars($gerecht['afbeelding']) ?>" class="img-fluid gerecht-image" alt="<?= htmlspecialchars($gerecht['naam']) ?>">
        </div>

        <div class="col-md-6 content-right">
            <h1>Ingrediënten</h1>
            <div class="scrollable-div">
                <p><h5>Voor de <?= htmlspecialchars($gerecht['naam']) ?>:</h5></p>
                <ul>
                    <?php foreach ($ingredienten as $ingredient): ?>
                        <li>
                            <?= htmlspecialchars($ingredient['naam']) ?>
                            <?= htmlspecialchars($ingredient['hoeveelheid']) ?>
                            <?= htmlspecialchars($ingredient['eenheid']) ?>
                            <?= htmlspecialchars($ingredient['beschrijving']) ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <h3>Bereiding:</h3>
            <div class="scrollable-div">
                <p><?= addParagraphs(htmlspecialchars($gerecht['beschrijving'])) ?></p>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
