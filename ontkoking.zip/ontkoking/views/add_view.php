<?php
session_start();
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerecht Toevoegen</title>
    <link rel="stylesheet" href="css/add.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>

<nav id="header" class="navbar navbar-expand-lg ">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">
            <img src="image/logo.PNG" alt="Logo" style="width: 150px;">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span id="burger" class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul id="knoppen" class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="add.php">Toevoegen</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact</a>
                </li>
            </ul>

            <ul class="navbar-nav ms-auto" id="login">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li id="log" class="nav-item">
                        <a id="profielBox" class="btn btn-outline-light d-flex align-items-center" href="profile.php">
                            <?php if (isset($_SESSION['profielfoto']) && $_SESSION['profielfoto'] != 'default.png'): ?>
                                <img src="uploads/<?= htmlspecialchars($_SESSION['profielfoto']) ?>" alt="Profielfoto" class="rounded-circle">
                            <?php else: ?>
                                <div id="profiel">👤</div>
                            <?php endif; ?>
                            <?= htmlspecialchars($_SESSION['username']) ?>
                        </a>
                        <a id="uitlog" class="btn btn-outline-light" href="logout.php">Uitloggen</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="btn btn-outline-light" href="login.php">Inloggen</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <h2>Nieuw Gerecht Toevoegen</h2>

    <form action="add_verwerk.php" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="dishName" class="form-label">Naam van het gerecht</label>
            <input type="text" class="form-control" id="dishName" name="naam" required>
        </div>

        <div class="mb-3">
            <label for="tijdsduur" class="form-label">Bereidingstijd (in minuten)</label>
            <input type="number" class="form-control" id="tijdsduur" name="tijdsduur" min="10" max="500" required>
            <span class="input-group-text">min.</span>
        </div>

        <div class="mb-3">
            <label for="moeilijkheidsgraad" class="form-label">Moeilijkheidsgraad (1 tot 10)</label>
            <input type="number" class="form-control" id="moeilijkheidsgraad" name="moeilijkheidsgraad" min="1" max="10" required>
        </div>

        <div class="mb-3">
            <label for="ingredient" class="form-label">Ingrediënten:</label>
            <div class="input-group">
                <input type="text" class="form-control" id="ingredient" placeholder="Voer ingrediënt in">
                <input type="number" class="form-control" id="hoeveelheid" placeholder="Hoeveelheid" style="width: 100px; margin-left: 10px;">
                <input type="text" class="form-control" id="eenheid" placeholder="Eenheid (bijv. gram, ml)" style="width: 120px; margin-left: 10px;">
                <button type="button" class="btn btn-primary" id="addIngredientBtn" style="margin-left: 10px;">Voeg ingrediënt toe</button>
            </div>
            <ul id="ingredientList" class="list-group mt-2"></ul>
        </div>

        <div class="mb-3">
            <label for="recipe" class="form-label">Bereidingswijze:</label>
            <textarea class="form-control" id="beschrijving" name="beschrijving" rows="5" required></textarea>
        </div>

        <div class="mb-3">
            <label for="dishImage" class="form-label">Afbeelding van het gerecht</label>
            <input type="file" class="form-control" id="dishImage" name="afbeelding" accept="image/*" required>
        </div>

        <button type="submit" class="btn btn-primary">Gerecht Toevoegen</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    let editIndex = null;

    document.getElementById('addIngredientBtn').addEventListener('click', function() {
        const ingredientInput = document.getElementById('ingredient');
        const hoeveelheidInput = document.getElementById('hoeveelheid');
        const eenheidInput = document.getElementById('eenheid');

        const ingredientValue = ingredientInput.value.trim();
        const hoeveelheidValue = hoeveelheidInput.value.trim();
        const eenheidValue = eenheidInput.value.trim();

        if (ingredientValue !== "" && hoeveelheidValue !== "" && eenheidValue !== "") {
            const ingredientList = document.getElementById('ingredientList');

            if (editIndex !== null) {
                const listItem = ingredientList.children[editIndex];
                listItem.innerHTML = `${ingredientValue} - ${hoeveelheidValue} ${eenheidValue}
                <button id=actions type="button" class="btn btn-warning btn-sm edit-ingredient">Bewerk</button>
                <button type="button" class="btn btn-danger btn-sm remove-ingredient">Verwijder</button>`;

                const hiddenInputs = document.querySelectorAll('input[type="hidden"]');
                hiddenInputs[editIndex * 3].value = ingredientValue;
                hiddenInputs[editIndex * 3 + 1].value = hoeveelheidValue;
                hiddenInputs[editIndex * 3 + 2].value = eenheidValue;

                editIndex = null;
                document.getElementById('addIngredientBtn').textContent = 'Voeg ingrediënt toe';
            } else {
                const newIngredientItem = document.createElement('li');
                newIngredientItem.className = 'list-group-item d-flex justify-content-between align-items-center';
                newIngredientItem.innerHTML = `${ingredientValue} - ${hoeveelheidValue} ${eenheidValue}
                    <button id=actions type="button" class="btn btn-warning btn-sm edit-ingredient action-btn">Bewerk</button>
                    <button type="button" class="btn btn-danger btn-sm remove-ingredient">Verwijder</button>`;

                ingredientList.appendChild(newIngredientItem);

                const hiddenIngredient = document.createElement('input');
                hiddenIngredient.type = 'hidden';
                hiddenIngredient.name = 'ingredients[]';
                hiddenIngredient.value = ingredientValue;

                const hiddenHoeveelheid = document.createElement('input');
                hiddenHoeveelheid.type = 'hidden';
                hiddenHoeveelheid.name = 'quantities[]';
                hiddenHoeveelheid.value = hoeveelheidValue;

                const hiddenEenheid = document.createElement('input');
                hiddenEenheid.type = 'hidden';
                hiddenEenheid.name = 'units[]';
                hiddenEenheid.value = eenheidValue;

                document.querySelector('form').appendChild(hiddenIngredient);
                document.querySelector('form').appendChild(hiddenHoeveelheid);
                document.querySelector('form').appendChild(hiddenEenheid);
            }

            ingredientInput.value = '';
            hoeveelheidInput.value = '';
            eenheidInput.value = '';
        }
    });

    document.getElementById('ingredientList').addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-ingredient')) {
            const listItem = e.target.parentElement;
            const index = Array.prototype.indexOf.call(ingredientList.children, listItem);
            listItem.remove();

            const hiddenInputs = document.querySelectorAll('input[type="hidden"]');
            hiddenInputs[index * 3].remove();
            hiddenInputs[index * 3 + 1].remove();
            hiddenInputs[index * 3 + 2].remove();
        } else if (e.target.classList.contains('edit-ingredient')) {
            const listItem = e.target.parentElement;
            const ingredientText = listItem.childNodes[0].textContent.trim();
            const [ingredient, hoeveelheidEenheid] = ingredientText.split(' - ');
            const [hoeveelheid, eenheid] = hoeveelheidEenheid.split(' ');

            document.getElementById('ingredient').value = ingredient;
            document.getElementById('hoeveelheid').value = hoeveelheid;
            document.getElementById('eenheid').value = eenheid;

            editIndex = Array.prototype.indexOf.call(ingredientList.children, listItem);

            document.getElementById('addIngredientBtn').textContent = 'Update Ingrediënt';
        }
    });
</script>

</body>
</html>
