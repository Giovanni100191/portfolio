<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profiel Bewerken</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/profile.css">
</head>
<body>

<nav id="header" class="navbar navbar-expand-lg ">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">
            <img src="image/logo.PNG" alt="Logo" style="width: 150px;">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span id="burger" class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul id="knoppen" class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="add.php">Toevoegen</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact</a>
                </li>
            </ul>

            <ul class="navbar-nav ms-auto" id="login">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <li id="log" class="nav-item">
                        <a id="profielBox" class="btn btn-outline-light d-flex align-items-center" href="profile.php">
                            <?php if (isset($_SESSION['profielfoto']) && $_SESSION['profielfoto'] != 'default.png'): ?>
                                <img src="uploads/<?= htmlspecialchars($_SESSION['profielfoto']) ?>" alt="Profielfoto" class="rounded-circle">
                            <?php else: ?>
                                <div id="profiel">👤</div>
                            <?php endif; ?>
                            <?= htmlspecialchars($_SESSION['username']) ?>
                        </a>
                        <a id="uitlog" class="btn btn-outline-light" href="logout.php">Uitloggen</a>
                    </li>
                <?php else: ?>
                    <li id="inlog2" class="nav-item">
                        <a class="btn btn-outline-light" href="login.php">Inloggen</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>


<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <h2 class="text-center">Profiel bewerken</h2>
            <form action="profile_update.php" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="username">Gebruikersnaam</label>
                    <input type="text" name="username" id="username" class="form-control" value="<?= htmlspecialchars($_SESSION['username']) ?>" required>
                </div>

                <div class="form-group mt-4">
                    <label for="profielfoto">Profielfoto</label>
                    <div id="currentProfielfoto" class="mb-3 text-center">
                        <?php if (isset($_SESSION['profielfoto']) && $_SESSION['profielfoto'] != 'default.png'): ?>
                            <img src="uploads/<?= htmlspecialchars($_SESSION['profielfoto']) ?>" alt="Profielfoto" class="rounded-circle" style="width: 150px; height: 150px;">
                        <?php else: ?>
                            <div id="profiel" style="font-size: 80px;">👤</div>
                        <?php endif; ?>
                    </div>
                    <input type="file" name="profielfoto" id="profielfoto" class="form-control">
                </div>

                <div class="form-group mt-4 text-center">
                    <button type="submit" class="btn btn-primary">Opslaan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.getElementById('profielfoto').addEventListener('change', function(event) {
        const [file] = event.target.files;
        if (file) {
            document.getElementById('currentProfielfoto').innerHTML = `<img src="${URL.createObjectURL(file)}" alt="Profielfoto" class="rounded-circle" style="width: 100px; height: 100px;">`;
        }
    });
</script>

</body>
</html>
