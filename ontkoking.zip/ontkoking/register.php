<?php

include "views/register_view.php";